package com.example.dtdcdeliveryapp;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class GoDeliveryPickingActivity extends AppCompatActivity {
    // Firebase
    FirebaseDatabase database;
    DatabaseReference myRef;
    // Definig Views
    RecyclerView rv_lot;
    ArrayList<Lot> lots;
    String order_no;
    Button btn_next, btn_save, btn_verify;
    ImageView imageView;
    TextView tv_order_no, tv_sku, tv_sku_desc, tv_bin_code, tv_pending_quantity, tv_distance;
    EditText et_bin_code_scan, et_sku_scan, et_qty_picked, et_box_id;
    public static final String TAG = "GoDeliveryPicking";
    public static ArrayList<String> lotNo;
    public static LotAdapter lotAdapter;
    public static int count = 0;
    boolean isCorrect;
    //********* Beacon Integration*******
    static final String SCAN = "com.google.zxing.client.android";
    ArrayList<String> bluetoothaddreses;
    private BluetoothAdapter mBluetoothAdapter;
    private int REQUEST_ENABLE_BT = 1;
    private Handler mHandler;
    private static final long SCAN_PERIOD = 10000;
    private BluetoothLeScanner mLEScanner;
    private ScanSettings settings;
    private List<ScanFilter> filters;
    private BluetoothGatt mGatt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_go_delivery_picking);
        // Initializing Views
        btn_save = findViewById(R.id.btn_save);
        btn_next = findViewById(R.id.btn_next);
        btn_verify = findViewById(R.id.btn_verify);
        et_qty_picked = findViewById(R.id.et_qty_picked);
        et_box_id = findViewById(R.id.et_box_id);
        rv_lot = findViewById(R.id.rv_lot);
        tv_distance = findViewById(R.id.tv_distance);
        tv_bin_code = findViewById(R.id.tv_bin_code);
        tv_order_no = findViewById(R.id.tv_order_no);
        tv_sku = findViewById(R.id.tv_sku);
        tv_sku_desc = findViewById(R.id.tv_sku_desc);
        tv_pending_quantity = findViewById(R.id.tv_pending_quantity);
        // Getting data from previous Intent
        Intent intentThatStartedThis = getIntent();
        isCorrect = intentThatStartedThis.getBooleanExtra("isCorrect", false);
        order_no = intentThatStartedThis.getStringExtra("order_no");
        String picking_mode =intentThatStartedThis.getStringExtra("picking_mode");
        lots = new ArrayList<>();
        tv_order_no.setText("Order No : " + order_no);
        lotNo = intentThatStartedThis.getStringArrayListExtra("lots");
        Log.d(TAG, "onCreate: " + lotNo);
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference();
        btn_next.setEnabled(false);
        if (isCorrect == true) {
            btn_verify.setText("Verified");
            btn_verify.setEnabled(false);
            btn_next.setEnabled(true);
        }
        if (lotNo == null) {
            lotNo = new ArrayList<>();
        }
        // Check and Request Permission for Location
        int perm = ContextCompat.checkSelfPermission(GoDeliveryPickingActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION);
        if(perm == PackageManager.PERMISSION_GRANTED){
            initBLE();
        }else{
            ActivityCompat.requestPermissions(GoDeliveryPickingActivity.this,
                    new String[] {
                            Manifest.permission.ACCESS_COARSE_LOCATION,
                            Manifest.permission.ACCESS_FINE_LOCATION
                    }, 121);
            initBLE();
        }
        Thread t = new Thread() {
            @Override
            public void run() {

                while (!isInterrupted()) {

                    try {
                        Thread.sleep(1000);  //1000ms = 1 sec

                        runOnUiThread(new Runnable() {

                            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                            @Override
                            public void run() {

                                mLEScanner.startScan(filters, settings, mScanCallback);
                            }
                        });

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
            }
        };
        t.start();
        myRef.child("Person1").child("orders").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                final Orders order = dataSnapshot.getValue(Orders.class);
                if (order.getOrder_no().equals(order_no)) {
                    tv_bin_code.setText(order.getBinCode());
                    tv_sku.setText("Sku : " + order.getSku());
                    tv_sku_desc.setText("Sku Desc : " + order.getSkuDesc());
                    tv_pending_quantity.setText(order.getPendingQuantity());
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        for (int i = 0; i < lotNo.size(); i++) {
            lots.add(new Lot("la" + String.valueOf(i + 1), lotNo.get(i)));
            if (i == lotNo.size() - 1) {
                et_qty_picked.setText(String.valueOf(i + 1));
            }


        }
        lotAdapter = new LotAdapter(lots);
        rv_lot.setLayoutManager(new GridLayoutManager(GoDeliveryPickingActivity.this,
                2,
                LinearLayoutManager.VERTICAL,
                false));
        rv_lot.setAdapter(lotAdapter);

        btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int perm = ContextCompat.checkSelfPermission(GoDeliveryPickingActivity.this,
                        Manifest.permission.CAMERA);
                if (perm == PackageManager.PERMISSION_GRANTED) {
                    usnScanner();
                } else {
                    ActivityCompat.requestPermissions(GoDeliveryPickingActivity.this,
                            new String[]{
                                    Manifest.permission.CAMERA
                            }, 121);
                          btn_next.callOnClick();
                }
            }
        });

        btn_verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int perm = ContextCompat.checkSelfPermission(GoDeliveryPickingActivity.this,
                        Manifest.permission.CAMERA);
                if (perm == PackageManager.PERMISSION_GRANTED) {
                    binCodeVerification();
                } else {
                    ActivityCompat.requestPermissions(GoDeliveryPickingActivity.this,
                            new String[]{
                                    Manifest.permission.CAMERA
                            }, 121);
                   btn_next.callOnClick();
                }
            }
        });
    }

    private void binCodeVerification() {
        Intent i = new Intent(GoDeliveryPickingActivity.this, BinCodeVerificationActivity.class);
        i.putExtra("order_no", order_no);
        i.putExtra("binCode", tv_bin_code.getText().toString());
        i.putExtra("isCorrect", isCorrect);
        startActivity(i);
    }
    public void usnScanner() {
        Intent i = new Intent(GoDeliveryPickingActivity.this, UsnScannerActivity.class);
        i.putExtra("lots", lotNo);
        i.putExtra("order_no", order_no);
        startActivity(i);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(GoDeliveryPickingActivity.this, DeliveryPickingActivity.class);
        startActivity(i);
    }
    private void initBLE() {
        //adding dummy value in bluetooth addresses
        bluetoothaddreses = new ArrayList<String>();
        bluetoothaddreses.add("addresses");
        mHandler = new Handler();
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Toast.makeText(this, "BLE Not Supported",
                    Toast.LENGTH_SHORT).show();
            finish();
        }
        final BluetoothManager bluetoothManager;
        bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();
    }
    @Override
    protected void onResume() {
        super.onResume();
        if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        } else {
            mLEScanner = mBluetoothAdapter.getBluetoothLeScanner();
            settings = new ScanSettings.Builder()
                    .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                    .build();
            filters = new ArrayList<ScanFilter>();
            scanLeDevice(true);
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        if (mBluetoothAdapter != null && mBluetoothAdapter.isEnabled()) {
            scanLeDevice(false);
        }
    }
    @Override
    protected void onDestroy() {
        if (mGatt == null) {
            return;
        }
        mGatt.close();
        mGatt = null;
        super.onDestroy();
    }
    private void scanLeDevice(final boolean enable) {
        if (enable) {
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mLEScanner.stopScan(mScanCallback);
                }
            }, SCAN_PERIOD);
            mLEScanner.startScan(filters, settings, mScanCallback); // main thread to be called again
        }
    }
    private ScanCallback mScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            Log.i("callbackType", String.valueOf(callbackType));
            Log.i("result", String.valueOf(result.getRssi()));
            BluetoothDevice btDevice = null;
            btDevice = result.getDevice();
            connectToDevice(btDevice);
            if (!bluetoothaddreses.contains(btDevice.toString())) {
                bluetoothaddreses.add(btDevice.toString());
            }
            if (btDevice.toString().equals("B0:91:22:F5:08:0F")) {
                Double rssi = Double.valueOf(result.getRssi());
                Double measurepwr;
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//                    measurepwr = Double.valueOf(result.getTxPower());
//                } else
                measurepwr = -90.0;
                Double power = (measurepwr - rssi) / (20.0);
                Double distance = Math. pow(10, power);
                DecimalFormat df2 = new DecimalFormat("#.##");
                tv_distance.setText(df2.format(distance) + " meters");
            }
            for (int i = 0; i < bluetoothaddreses.size(); i++) {
                Log.d("ADRESSES!!!!", bluetoothaddreses.get(i));
            }
        }
        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            for (ScanResult sr : results) {
                Log.i("ScanResult - Results", sr.toString());
            }
        }
        @Override
        public void onScanFailed(int errorCode) {
            Log.e("Scan Failed", "Error Code: " + errorCode);
        }
    };
    private BluetoothAdapter.LeScanCallback mLeScanCallback =
            new BluetoothAdapter.LeScanCallback() {
                @Override
                public void onLeScan(final BluetoothDevice device, int rssi,
                                     byte[] scanRecord) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.i("onLeScan", device.toString());
                            connectToDevice(device);
                        }
                    });
                }
            };
    public void connectToDevice(BluetoothDevice device) {
        if (mGatt == null) {
            mGatt = device.connectGatt(this, false, gattCallback);
            scanLeDevice(false);// will stop after first device detection
        }
    }
    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            Log.i("onConnectionStateChange", "Status: " + status);
            switch (newState) {
                case BluetoothProfile.STATE_CONNECTED:
                    Log.i("gattCallback", "STATE_CONNECTED");
                    gatt.discoverServices();
                    break;
                case BluetoothProfile.STATE_DISCONNECTED:
                    Log.e("gattCallback", "STATE_DISCONNECTED");
                    break;
                default:
                    Log.e("gattCallback", "STATE_OTHER");
            }

        }
        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            List<BluetoothGattService> services = gatt.getServices();
            Log.i("onServicesDiscovered", services.toString());
            gatt.readCharacteristic(services.get(1).getCharacteristics().get
                    (0));
        }
        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic
                                                 characteristic, int status) {
            Log.i("onCharacteristicRead", characteristic.toString());
            gatt.disconnect();
        }
    };
    private Dialog showDialog(final GoDeliveryPickingActivity goDeliveryPickingActivity, String no_scanner_found, String s, String s1, String no) {
        // a subclass of dialog that can display buttons and message
        AlertDialog.Builder download = new AlertDialog.Builder(goDeliveryPickingActivity);
        download.setTitle(no_scanner_found);
        download.setMessage(s);
        download.setPositiveButton(s1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                // TODO Auto-generated method stub
                //uri to download barcode scanner
                Uri uri = Uri.parse("market://search?q=pname:" + "com.google.zxing.client.android");
                Intent in = new Intent(Intent.ACTION_VIEW, uri);
                try {
                   goDeliveryPickingActivity.startActivity(in);
                } catch (ActivityNotFoundException e) {

                }
            }
        });
        download.setNegativeButton(no, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                // TODO Auto-generated method stub
            }
        });
        return download.show();
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent in) {
        if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == Activity.RESULT_CANCELED) {
                //Bluetooth not enabled.
                finish();
                return;
            }
        }
        // TODO Auto-generated method stub
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, in);
        if (result != null) {
            if (result.getContents() == null) {
                Toast.makeText(this, "Cancelled", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Scanned: " + result.getContents(), Toast.LENGTH_LONG).show();
            }
        } else {
            super.onActivityResult(requestCode, resultCode, in);
        }
    }

}




