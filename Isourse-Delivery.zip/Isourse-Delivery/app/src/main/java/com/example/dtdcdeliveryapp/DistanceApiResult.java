package com.example.dtdcdeliveryapp;



import java.util.ArrayList;

public class DistanceApiResult {
    private String authenticationResultCode;
    private String brandLogoUri;
    private String copyright;
    private ArrayList<ResourceSet> resourceSets;
    class ResourceSet{
        private int estimatedTotal;
        private ArrayList<resource> resources;
        class resource{
            private String __type;
            private ArrayList<location> destinations;
            private String errorMessage;
            private ArrayList<location> origins;
            private ArrayList<result> results;
            class result{


                private String departureTime;
                private int destinationIndex;
                private int originIndex;
                private int totalWalkDuration;
                private float travelDistance;
                private float travelDuration;

                public result() {
                }

                public result(String departureTime, int destinationIndex, int originIndex, int totalWalkDuration, float travelDistance, float travelDuration) {
                    this.departureTime = departureTime;
                    this.destinationIndex = destinationIndex;
                    this.originIndex = originIndex;
                    this.totalWalkDuration = totalWalkDuration;
                    this.travelDistance = travelDistance;
                    this.travelDuration = travelDuration;
                }
                public void setDepartureTime(String departureTime) {
                    this.departureTime = departureTime;
                }

                public String getDepartureTime() {
                    return departureTime;
                }

                public int getDestinationIndex() {
                    return destinationIndex;
                }

                public void setDestinationIndex(int destinationIndex) {
                    this.destinationIndex = destinationIndex;
                }

                public int getOriginIndex() {
                    return originIndex;
                }

                public void setOriginIndex(int originIndex) {
                    this.originIndex = originIndex;
                }

                public int getTotalWalkDuration() {
                    return totalWalkDuration;
                }

                public void setTotalWalkDuration(int totalWalkDuration) {
                    this.totalWalkDuration = totalWalkDuration;
                }

                public float getTravelDistance() {
                    return travelDistance;
                }

                public void setTravelDistance(float travelDistance) {
                    this.travelDistance = travelDistance;
                }

                public float getTravelDuration() {
                    return travelDuration;
                }

                public void setTravelDuration(float travelDuration) {
                    this.travelDuration = travelDuration;
                }
            }
            class location{
                private double latitude;
                private double longitude;

                public location() {
                }

                public location(double latitude, double longitude) {
                    this.latitude = latitude;
                    this.longitude = longitude;
                }

                public double getLatitude() {
                    return latitude;
                }

                public void setLatitude(double latitude) {
                    this.latitude = latitude;
                }

                public double getLongitude() {
                    return longitude;
                }

                public void setLongitude(double longitude) {
                    this.longitude = longitude;
                }
            }

            public resource(String __type, ArrayList<location> destinations, String errorMessage, ArrayList<location> origins, ArrayList<result> results) {
                this.__type = __type;
                this.destinations = destinations;
                this.errorMessage = errorMessage;
                this.origins = origins;
                this.results = results;
            }

            public resource() {
            }

            public String get__type() {
                return __type;
            }

            public void set__type(String __type) {
                this.__type = __type;
            }

            public ArrayList<location> getDestinations() {
                return destinations;
            }

            public void setDestinations(ArrayList<location> destinations) {
                this.destinations = destinations;
            }

            public String getErrorMessage() {
                return errorMessage;
            }

            public void setErrorMessage(String errorMessage) {
                this.errorMessage = errorMessage;
            }

            public ArrayList<location> getOrigins() {
                return origins;
            }

            public void setOrigins(ArrayList<location> origins) {
                this.origins = origins;
            }

            public ArrayList<result> getResults() {
                return results;
            }

            public void setResults(ArrayList<result> results) {
                this.results = results;
            }
        }

        public ResourceSet(int estimatedTotal, ArrayList<resource> resources) {
            this.estimatedTotal = estimatedTotal;
            this.resources = resources;
        }

        public int getEstimatedTotal() {
            return estimatedTotal;
        }

        public void setEstimatedTotal(int estimatedTotal) {
            this.estimatedTotal = estimatedTotal;
        }

        public ArrayList<resource> getResources() {
            return resources;
        }

        public void setResources(ArrayList<resource> resources) {
            this.resources = resources;
        }

        public ResourceSet() {
        }
    }
    private int statusCode;
    private String statusDescription;
    private String traceId;

    public DistanceApiResult(String authenticationResultCode, String brandLogoUri, String copyright, ArrayList<ResourceSet> resourceSets, int statusCode, String statusDescription, String traceId) {
        this.authenticationResultCode = authenticationResultCode;
        this.brandLogoUri = brandLogoUri;
        this.copyright = copyright;
        this.resourceSets = resourceSets;
        this.statusCode = statusCode;
        this.statusDescription = statusDescription;
        this.traceId = traceId;
    }

    public DistanceApiResult() {
    }

    public String getAuthenticationResultCode() {
        return authenticationResultCode;
    }

    public void setAuthenticationResultCode(String authenticationResultCode) {
        this.authenticationResultCode = authenticationResultCode;
    }

    public String getBrandLogoUri() {
        return brandLogoUri;
    }

    public void setBrandLogoUri(String brandLogoUri) {
        this.brandLogoUri = brandLogoUri;
    }

    public String getCopyright() {
        return copyright;
    }

    public void setCopyright(String copyright) {
        this.copyright = copyright;
    }

    public ArrayList<ResourceSet> getResourceSets() {
        return resourceSets;
    }

    public void setResourceSets(ArrayList<ResourceSet> resourceSets) {
        this.resourceSets = resourceSets;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusDescription() {
        return statusDescription;
    }

    public void setStatusDescription(String statusDescription) {
        this.statusDescription = statusDescription;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }
}
