package com.example.dtdcdeliveryapp;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.MediaType;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LoginActivity extends AppCompatActivity {
    private static final String TAG = "LoginActivity";
    EditText et_username, et_password;
    Button btn_login;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        et_username = findViewById(R.id.et_username);
        et_password = findViewById(R.id.et_password);
        btn_login = findViewById(R.id.btn_login);
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = et_username.getText().toString();
                String password = et_password.getText().toString();
                User user = new User();
                user.jsonpwd=password;
                user.jsonid=username;
                try {
                    sendNetworkRequest(user);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
//                Gson gson = new Gson();
//                String json = gson.toJson(user);
//                try {
//                    JSONObject jsonObject = new JSONObject(json);
//                    sendNetworkRequest(jsonObject);
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//
//
//                try {
//                    JSONObject jsonObject = new JSONObject(json);
//                    sendNetworkRequest(jsonObject);
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
            }
        });
    }

    private void sendNetworkRequest(User user) throws JSONException {
        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl("http://103.196.222.81:100/webservice.asmx/")
                .addConverterFactory(GsonConverterFactory.create());
        Retrofit retrofit = builder.build();
        UserClient client = retrofit.create(UserClient.class);
//        JSONObject a = new JSONObject();
//        String b = a.toString().substring(1, a.toString().length() - 1);
        Call<ResponseBody> call = client.createAccount(user);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                Log.d("MOCK!!!", response.body().byteStream().toString());

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

            }
//            @Override
//            public void onResponse(Call<ResponseBody> call, Response<User> response) {
//
//                ResponseBody responseBody = response.body();
////                ResponseBody resp = ResponseBody.create(MediaType.parse("application/json"), String.valueOf(response));
//                Log.d(TAG, "onResponse: " + response.body().byteStream());
//            }
//
//            @Override
//            public void onFailure(Call<User> call, Throwable t) {
//                Log.d(TAG, "onFailure: ");
//                t.printStackTrace();
//
//            }
        });
    }
}
