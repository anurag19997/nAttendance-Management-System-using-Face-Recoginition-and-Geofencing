package com.example.dtdcdeliveryapp.Adapters;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.dtdcdeliveryapp.PutawayInfo;
import com.example.dtdcdeliveryapp.R;

import java.util.ArrayList;

 public class PutawayInfoAdapter extends RecyclerView.Adapter<PutawayInfoAdapter.PutawayInfoViewHolder> {
    ArrayList<PutawayInfo> putawayInfos;

    public PutawayInfoAdapter(ArrayList<PutawayInfo> putawayInfos) {
        this.putawayInfos = putawayInfos;
    }

    @NonNull
    @Override
    public PutawayInfoViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater li = (LayoutInflater) viewGroup.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View itemView = li.inflate(R.layout.list_item_usn_checked, viewGroup, false);
        return  new PutawayInfoAdapter.PutawayInfoViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull PutawayInfoViewHolder putawayInfoViewHolder, int i) {
        PutawayInfo putawayInfo = putawayInfos.get(i);
        putawayInfoViewHolder.tv_no.setText(String.valueOf(putawayInfo.getNo()));
        putawayInfoViewHolder.tv_bincode.setText(putawayInfo.getBincode());
        putawayInfoViewHolder.tv_info.setText(putawayInfo.getInfo());
    }

    @Override
    public int getItemCount() {
        return putawayInfos.size();
    }

    public class PutawayInfoViewHolder extends RecyclerView.ViewHolder {
        TextView tv_no, tv_bincode, tv_info;
        public PutawayInfoViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_no = itemView.findViewById(R.id.tv_no);
            tv_bincode = itemView.findViewById(R.id.tv_bincode);
            tv_info = itemView.findViewById(R.id.tv_info);
        }
    }
}
