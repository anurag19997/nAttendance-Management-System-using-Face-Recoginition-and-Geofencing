package com.example.dtdcdeliveryapp;

import android.content.Intent;

import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.dtdcdeliveryapp.Adapters.PutawayInfoAdapter;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class PutawayActivity extends AppCompatActivity {
    private static final String TAG = "PutawayActivity";
    private ZXingScannerView scannerView;
    LinearLayout linearLayoutUsn, linearLayoutSku;
    CheckBox cb_sku, cb_usn, cb_fix;
    TextView tv_sku, tv_usn;
    RecyclerView rv_usn, rv_sku;
    EditText et_bincode, et_usn, et_sku, et_count, et_last_scan;
    Button btn_put;
    Boolean bincodePressed, usnPressed, skuPressed, is_sku_checked, is_fixed;
    String bincode;
    ArrayList<PutawayInfo> putawayInfos;
    ArrayList<PutawayInfo> usnPutawayInfos, skuPutawayInfos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_putaway);
//        int perm = ContextCompat.checkSelfPermission(PutawayActivity.this, Manifest.permission.CAMERA);
//        if(perm == PackageManager.PERMISSION_DENIED) {
//            ActivityCompat.requestPermissions(PutawayActivity.this,
//                    new String[]{
//                            Manifest.permission.READ_EXTERNAL_STORAGE,
//                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
//                            Manifest.permission.CAMERA
//                    },
//                    126);
//        }
        Intent i = getIntent();
        is_fixed = i.getBooleanExtra("is_fixed", false);
        is_sku_checked = i.getBooleanExtra("is_sku_checked", false);
        bincodePressed = i.getBooleanExtra("bincodePressed", false);
        usnPressed = i.getBooleanExtra("usnPressed", false);
        skuPressed = i.getBooleanExtra("skuPressed", false);
        String result = i.getStringExtra("result");
        bincode = i.getStringExtra("bincode");
        et_bincode = findViewById(R.id.et_bincode);
        et_count = findViewById(R.id.et_count);
        et_last_scan = findViewById(R.id.et_last_scan);
        et_sku = findViewById(R.id.et_sku);
        et_usn = findViewById(R.id.et_usn);
        cb_fix = findViewById(R.id.cb_fix);
        cb_sku = findViewById(R.id.cb_sku);
        cb_usn = findViewById(R.id.cb_usn);
        linearLayoutUsn = findViewById(R.id.linearLayout3);
        linearLayoutSku = findViewById(R.id.linearLayout);
        tv_sku = findViewById(R.id.tv_sku);
        tv_usn = findViewById(R.id.tv_usn);
        rv_sku = findViewById(R.id.rv_sku);
        rv_usn = findViewById(R.id.rv_usn);
        btn_put = findViewById(R.id.btn_put);
        putawayInfos = new ArrayList<>();
        usnPutawayInfos = new ArrayList<>();
        skuPutawayInfos = new ArrayList<>();
        if (is_fixed) {
            cb_fix.setChecked(true);
        }if (is_sku_checked) {
            cb_sku.setChecked(true);
            cb_sku.callOnClick();

        }else {
            cb_usn.setChecked(true);
            cb_usn.callOnClick();
        }
        File dataDir = ContextCompat.getDataDir(PutawayActivity.this);
        File PutawayFile = new File(dataDir, "PutawayFile.txt");
        try {
            FileInputStream fis = new FileInputStream(PutawayFile);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String buffer = br.readLine();
            while (buffer != null) {
                sb.append(buffer);
                buffer = br.readLine();
            }
            String text = sb.toString();
            putawayInfos = putawayInfoList(text);
            Log.d(TAG, "onCreate: " + text);
        } catch (FileNotFoundException fnfe) {
            //Toast.makeText(PutawayActivity.this, "File not found", Toast.LENGTH_SHORT).show();
        } catch (IOException ioe) {
            Toast.makeText(PutawayActivity.this, "Error while reading file", Toast.LENGTH_SHORT).show();
        }
        if (bincodePressed) {
            et_bincode.setText(result);
            bincode = result;
        } else if (usnPressed) {
            et_usn.setText(result);
        } else if (skuPressed) {
            et_sku.setText(result);
        }
        et_bincode.setText(bincode);
        final PutawayInfoAdapter usnPutawayAdapter = new PutawayInfoAdapter(usnPutawayInfos);
        final PutawayInfoAdapter skuPutawayAdapter = new PutawayInfoAdapter(skuPutawayInfos);
        rv_usn.setLayoutManager(new LinearLayoutManager(PutawayActivity.this,
                LinearLayoutManager.VERTICAL,
                false));
        rv_sku.setLayoutManager(new LinearLayoutManager(PutawayActivity.this,
                LinearLayoutManager.VERTICAL,
                false));
        rv_usn.setAdapter(usnPutawayAdapter);
        rv_sku.setAdapter(skuPutawayAdapter);
        for (int j = 0; j < putawayInfos.size(); j++) {
            if (putawayInfos.get(j).getModeOfPutaway().equals("usn")) {
                putawayInfos.get(j).setNo(usnPutawayInfos.size() + 1);
                usnPutawayInfos.add(putawayInfos.get(j));
                usnPutawayAdapter.notifyDataSetChanged();
            }
            if (putawayInfos.get(j).getModeOfPutaway().equals("sku")) {
                putawayInfos.get(j).setNo(skuPutawayInfos.size() + 1);
                skuPutawayInfos.add(putawayInfos.get(j));
                skuPutawayAdapter.notifyDataSetChanged();
            }
        }
        if (cb_usn.isChecked()) {
            et_count.setText(String.valueOf(usnPutawayInfos.size()));
            if (usnPutawayInfos.size() > 0) {
                et_last_scan.setText(usnPutawayInfos.get(usnPutawayInfos.size() - 1).getInfo());
            }
        } else {
            et_count.setText(String.valueOf(skuPutawayInfos.size()));
            if (skuPutawayInfos.size() > 0) {
                et_last_scan.setText(skuPutawayInfos.get(skuPutawayInfos.size() - 1).getInfo());
            }
        }
        et_bincode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bincodePressed = true;
                usnPressed = false;
                skuPressed = false;
                Intent i = new Intent(PutawayActivity.this, BasicScannerActivity.class);
                i.putExtra("is_fixed", cb_fix.isChecked());
                i.putExtra("is_sku_checked", cb_sku.isChecked());
                i.putExtra("bincodePressed", bincodePressed);
                i.putExtra("usnPressed", usnPressed);
                i.putExtra("skuPressed", skuPressed);
                startActivity(i);
            }
        });
        et_sku.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bincodePressed = false;
                usnPressed = false;
                skuPressed = true;
                Intent i = new Intent(PutawayActivity.this, BasicScannerActivity.class);
                i.putExtra("is_fixed", cb_fix.isChecked());
                i.putExtra("is_sku_checked", cb_sku.isChecked());
                i.putExtra("bincodePressed", bincodePressed);
                i.putExtra("usnPressed", usnPressed);
                i.putExtra("skuPressed", skuPressed);
                i.putExtra("bincode", bincode);
                startActivity(i);
            }
        });
        et_usn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bincodePressed = false;
                usnPressed = true;
                skuPressed = false;
                Intent i = new Intent(PutawayActivity.this, BasicScannerActivity.class);
                i.putExtra("is_fixed", cb_fix.isChecked());
                i.putExtra("is_sku_checked", cb_sku.isChecked());
                i.putExtra("bincodePressed", bincodePressed);
                i.putExtra("usnPressed", usnPressed);
                i.putExtra("skuPressed", skuPressed);
                i.putExtra("bincode", bincode);
                startActivity(i);

            }
        });
        btn_put.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (et_bincode.getText().toString().isEmpty() || (cb_usn.isChecked() && et_usn.getText().toString().isEmpty()) || (cb_sku.isChecked() && et_sku.getText().toString().isEmpty())) {
                    Toast.makeText(PutawayActivity.this, "Please Fill the Required Fields", Toast.LENGTH_SHORT).show();
                } else {
                    String Bincode = et_bincode.getText().toString();
                    String ModeOfPayment;
                    String Info;
                    Boolean isScanned = false;
                    if (cb_usn.isChecked()) {
                        ModeOfPayment = "usn";
                        Info = et_usn.getText().toString();
                        PutawayInfo usnPutawayInfo = new PutawayInfo(usnPutawayInfos.size() + 1, Bincode, ModeOfPayment, Info);
                        for (int k = 0; k < usnPutawayInfos.size(); k++) {
                            if (usnPutawayInfos.get(k).getInfo().equals(Info)) {
                                isScanned = true;
                            }
                        }
                        if (isScanned) {
                            Toast.makeText(PutawayActivity.this, "Already Scanned", Toast.LENGTH_SHORT).show();
                        } else {
                            usnPutawayInfos.add(usnPutawayInfo);
                            usnPutawayAdapter.notifyDataSetChanged();
                            clear(et_usn);
                            if (usnPutawayInfos.size() > 0) {
                                et_last_scan.setText(usnPutawayInfos.get(usnPutawayInfos.size() - 1).getInfo());
                            }
                            et_count.setText(String.valueOf(usnPutawayInfos.size()));
                        }

                    } else {
                        ModeOfPayment = "sku";
                        Info = et_sku.getText().toString();
                        PutawayInfo skuPutawayInfo = new PutawayInfo(skuPutawayInfos.size() + 1, Bincode, ModeOfPayment, Info);
                        for (int k = 0; k < skuPutawayInfos.size(); k++) {
                            if (skuPutawayInfos.get(k).getInfo().equals(Info)) {
                                isScanned = true;
                            }
                        }
                        if (isScanned) {
                            Toast.makeText(PutawayActivity.this, "Already Scanned", Toast.LENGTH_SHORT).show();
                        } else {
                            skuPutawayInfos.add(skuPutawayInfo);
                            skuPutawayAdapter.notifyDataSetChanged();
                            clear(et_sku);
                            if (skuPutawayInfos.size() > 0) {
                                et_last_scan.setText(skuPutawayInfos.get(skuPutawayInfos.size() - 1).getInfo());
                            }
                            et_count.setText(String.valueOf(skuPutawayInfos.size()));
                        }
                    }
                    if (!isScanned) {
                        PutawayInfo putawayInfo = new PutawayInfo(putawayInfos.size() + 1, Bincode, ModeOfPayment, Info);
                        putawayInfos.add(putawayInfo);
                        Gson gson = new Gson();
                        String json = gson.toJson(putawayInfos);
                        Log.d(TAG, "onClick: " + json);
                        File dataDir = ContextCompat.getDataDir(PutawayActivity.this);
                        File PutawayFile = new File(dataDir, "PutawayFile.txt");
                        if (!cb_fix.isChecked()) {
                            clear(et_bincode);
                        }
                        if (PutawayFile.exists()) {
                            PutawayFile.delete();
                        }
                        try {
                            FileOutputStream fos = new FileOutputStream(PutawayFile, true);
                            fos.write(json.getBytes());
                        } catch (FileNotFoundException fnfe) {
                            Toast.makeText(PutawayActivity.this, "File not found", Toast.LENGTH_SHORT).show();
                        } catch (IOException ioe) {
                            Toast.makeText(PutawayActivity.this, "Error while writing file", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
        if ((!et_bincode.getText().toString().isEmpty() && (cb_usn.isChecked()) && (!et_usn.getText().toString().isEmpty())) || (!et_bincode.getText().toString().isEmpty() && (cb_sku.isChecked()) && (!et_sku.getText().toString().isEmpty()))) {
            btn_put.callOnClick();
        }
    }

    public void onCheckboxClicked(View view) {
        boolean checked = ((CheckBox) view).isChecked();
        switch (view.getId()) {
            case R.id.cb_usn:
                if (checked) {
                    clear(et_bincode);
                    linearLayoutUsn.setVisibility(View.VISIBLE);
                    tv_usn.setVisibility(View.VISIBLE);
                    rv_usn.setVisibility(View.VISIBLE);
                    linearLayoutSku.setVisibility(View.INVISIBLE);
                    tv_sku.setVisibility(View.INVISIBLE);
                    rv_sku.setVisibility(View.INVISIBLE);
                    cb_sku.setChecked(false);
                    et_count.setText(String.valueOf(usnPutawayInfos.size()));
                    if (usnPutawayInfos.size() > 0) {
                        et_last_scan.setText(usnPutawayInfos.get(usnPutawayInfos.size() - 1).getInfo());
                    }
                } else {
                    clear(et_bincode);
                    cb_sku.setChecked(true);
                    linearLayoutSku.setVisibility(View.VISIBLE);
                    tv_sku.setVisibility(View.VISIBLE);
                    rv_sku.setVisibility(View.VISIBLE);
                    linearLayoutUsn.setVisibility(View.INVISIBLE);
                    tv_usn.setVisibility(View.INVISIBLE);
                    rv_usn.setVisibility(View.INVISIBLE);
                    cb_usn.setChecked(false);
                    et_count.setText(String.valueOf(skuPutawayInfos.size()));
                    if (skuPutawayInfos.size() > 0) {
                        et_last_scan.setText(skuPutawayInfos.get(skuPutawayInfos.size() - 1).getInfo());
                    }
                }
                break;
            case R.id.cb_sku:
                if (checked) {
                    if (skuPutawayInfos.size() > 0) {
                        et_last_scan.setText(skuPutawayInfos.get(skuPutawayInfos.size() - 1).getInfo());
                    }
                    clear(et_bincode);
                    linearLayoutSku.setVisibility(View.VISIBLE);
                    tv_sku.setVisibility(View.VISIBLE);
                    rv_sku.setVisibility(View.VISIBLE);
                    linearLayoutUsn.setVisibility(View.INVISIBLE);
                    tv_usn.setVisibility(View.INVISIBLE);
                    rv_usn.setVisibility(View.INVISIBLE);
                    cb_usn.setChecked(false);
                    et_count.setText(String.valueOf(skuPutawayInfos.size()));
                }
                // Cheese me
                else {
                    if (usnPutawayInfos.size() > 0) {
                        et_last_scan.setText(usnPutawayInfos.get(usnPutawayInfos.size() - 1).getInfo());
                    }
                    clear(et_bincode);
                    cb_usn.setChecked(true);
                    linearLayoutUsn.setVisibility(View.VISIBLE);
                    tv_usn.setVisibility(View.VISIBLE);
                    rv_usn.setVisibility(View.VISIBLE);
                    linearLayoutSku.setVisibility(View.INVISIBLE);
                    tv_sku.setVisibility(View.INVISIBLE);
                    rv_sku.setVisibility(View.INVISIBLE);
                    cb_sku.setChecked(false);
                    et_count.setText(String.valueOf(usnPutawayInfos.size()));
                }

                break;
            // TODO: Veggie sandwich
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(PutawayActivity.this, InboundActivity.class);
        startActivity(i);
    }

    public ArrayList<PutawayInfo> putawayInfoList(String response) {
        ArrayList<PutawayInfo> putawayInfoList = new ArrayList<>();
        JSONArray jsonArr = new JSONArray();
        try {
            jsonArr = new JSONArray(response);
            for (int i = 0; i < jsonArr.length(); i++) {
                JSONObject object = jsonArr.getJSONObject(i);
                int no = object.getInt("no");
                String bincode = object.getString("bincode");
                String modeOfPutaway = object.getString("modeOfPutaway");
                String info = object.getString("info");
                PutawayInfo putawayInfo = new PutawayInfo(PutawayInfo.getTotalCount() + 1, bincode, modeOfPutaway, info);
                putawayInfoList.add(putawayInfo);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return putawayInfoList;
    }

    public void clear(EditText editText) {
        String s = "";
        editText.setText(s);
    }

}
