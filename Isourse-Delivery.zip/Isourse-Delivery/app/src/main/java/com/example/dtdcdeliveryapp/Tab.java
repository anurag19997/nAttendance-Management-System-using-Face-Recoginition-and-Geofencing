package com.example.dtdcdeliveryapp;

public class Tab {
    String name;
    int res;
    int id;

    public int getRes() {
        return res;
    }

    public void setRes(int res) {
        this.res = res;
    }



    public Tab() {
    }

    public Tab(String name, int res, int id) {
        this.name = name;
        this.res = res;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
