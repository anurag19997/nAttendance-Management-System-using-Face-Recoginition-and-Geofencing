package com.example.dtdcdeliveryapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class LastMileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_last_mile);
    }
}
