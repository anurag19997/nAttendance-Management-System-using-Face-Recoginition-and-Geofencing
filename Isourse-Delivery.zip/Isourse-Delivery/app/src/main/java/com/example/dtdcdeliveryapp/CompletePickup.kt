package com.example.dtdcdeliveryapp

data class CompletePickup(val title : String, val subTitle : String, val pickupStatus : String)