package com.example.dtdcdeliveryapp;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

import com.example.dtdcdeliveryapp.Adapters.TabAdapter;

import java.util.ArrayList;

public class OutboundActivity extends AppCompatActivity {
//    ImageView iv_batch_picking, iv_delivery_picking, iv_batch_pick_sortation;
RecyclerView rv_outbound;
    ArrayList<Tab> tabs;
    TabAdapter tabAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_outbound);
//        iv_delivery_picking = findViewById(R.id.iv_delivery_picking);
//        iv_delivery_picking.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i =new Intent(OutboundActivity.this, DeliveryPickingActivity.class);
//                startActivity(i);
//            }
//        });
        rv_outbound = findViewById(R.id.rv_outbound);
        tabs = new ArrayList<>();
        tabAdapter = new TabAdapter(tabs);
        tabGenerator(5);

        rv_outbound.setLayoutManager(new GridLayoutManager(
                this,
                1,
                LinearLayoutManager.VERTICAL,
                false
        ));
        rv_outbound.setAdapter(tabAdapter);
        rv_outbound.addOnItemTouchListener(new RecyclerTouchListener(OutboundActivity.this,rv_outbound, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                switch (position){
                    case 0 :
//                        Intent i0 = new Intent(OutboundActivity.this, .class);
//                        startActivity(i0);
//                        break;
                    case 1 :
                        Intent i1 = new Intent(OutboundActivity.this, DeliveryPickingActivity.class);
                        startActivity(i1);
                        break;
                    case 2 :
//                        Intent i2 = new Intent(OutboundActivity.this, InventoryActivity.class);
//                        startActivity(i2);
//                        break;

                }
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i= new Intent(OutboundActivity.this, Main3Activity.class);
        startActivity(i);
    }

    public void tabGenerator(int n){

        Tab tab1 = new Tab("Batch Picking", R.drawable.batch_picking_image, 11);
        tabs.add(tab1);
        Tab tab2 = new Tab("Delivery Picking", R.drawable.delivery_picking_image, 12);
        tabs.add(tab2);
        Tab tab3 = new Tab("Batch Pick Sortation", R.drawable.batch_pick_sortation, 13);
        tabs.add(tab3);
        tabAdapter.notifyDataSetChanged();

    }
}
