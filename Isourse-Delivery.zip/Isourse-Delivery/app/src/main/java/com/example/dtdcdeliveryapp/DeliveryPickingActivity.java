package com.example.dtdcdeliveryapp;

import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class DeliveryPickingActivity extends AppCompatActivity {
    public static final String TAG = "DeliveryPicking";
    Spinner spinner_picking_mode, spinner_order_no, spinner_client;
    Button  btn_reset, btn_go;
    TextView tv_client;
    ArrayList<String> picking_mode;
    ArrayList<String> client;
    ArrayList<String> order_no;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_picking);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference myRef = database.getReference();
//        HashMap<String,Boolean> hashMap = new HashMap<>();
//        hashMap.put( "00000031", false);
//        hashMap.put( "00000032", false);
//        hashMap.put( "00000033", false);
//        hashMap.put( "00000034", false);
//        hashMap.put( "00000035", false);
//        hashMap.put( "00000036", false);
 //    Orders order1 = new Orders("AFGH", "2345", "jfhw", "sdhfjs", "00000032", "6");
//        hashMap.clear();
//        hashMap.put( "00000031", false);
//        hashMap.put( "00000032", false);
 //Orders order2 = new Orders( "ISOURSE","123", "ghjk", "dhfjkf", "00008126", "2");
        tv_client = findViewById(R.id.tv_client);
        picking_mode = new ArrayList<>();
        client = new ArrayList<>();
        order_no = new ArrayList<>();
       // spinner_client = findViewById(R.id.spinner_client);
        spinner_order_no = findViewById(R.id.spinner_order_no);
        spinner_picking_mode = findViewById(R.id.spinner_picking_mode);
        btn_go = findViewById(R.id.btn_go);
        btn_reset = findViewById(R.id.btn_reset);
        clear();
        picking_mode.add("Piece Picking");
        picking_mode.add("Bulk Picking");
       //myRef.child("Person1").child("orders").push().setValue(order1);
     //myRef.child("Person1").child("orders").push().setValue(order2);

        spinner_picking_mode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        final ArrayAdapter pickingAdapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item,picking_mode);
        pickingAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_picking_mode.setAdapter(pickingAdapter);

        final ArrayAdapter orderNoAdapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item, order_no);
        orderNoAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_order_no.setAdapter(orderNoAdapter);

        myRef.child("Person1").child("orders").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull final DataSnapshot dataSnapshot, @Nullable String s) {
                final Orders order = dataSnapshot.getValue(Orders.class);
                Log.d(TAG, "onChildAdded: "+order.getOrder_no());
               // Log.d(TAG, "onChildAdded: " + order);
                order_no.add(order.getOrder_no());
                orderNoAdapter.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        spinner_order_no.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, final int position, long id) {
                myRef.child("Person1").child("orders").addChildEventListener(new ChildEventListener() {
                    @Override
                    public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                        final Orders order2 = dataSnapshot.getValue(Orders.class);
                        if(order2.getOrder_no().equals(order_no.get(position))){
                            tv_client.setText(order2.getClient());
                        }
                    }

                    @Override
                    public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

                    }

                    @Override
                    public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        btn_go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(DeliveryPickingActivity.this, GoDeliveryPickingActivity.class);
                i.putExtra("order_no", spinner_order_no.getSelectedItem().toString());
                i.putExtra("client", tv_client.getText().toString());
                i.putExtra("picking_mode", spinner_picking_mode.getSelectedItem().toString());
                startActivity(i);
            }
        });
        btn_reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clear();
            }
        });
    }
    public void clear(){
        tv_client.setText("");
        order_no.add("Select");
        picking_mode.add("Select");
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(DeliveryPickingActivity.this, OutboundActivity.class);
        startActivity(i);
    }
}
