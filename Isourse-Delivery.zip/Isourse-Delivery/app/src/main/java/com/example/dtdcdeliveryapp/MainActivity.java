package com.example.dtdcdeliveryapp;

import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    ImageView iv_inbound, iv_outbound, iv_inventory, iv_first_mile, iv_last_mile;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv_inbound =findViewById(R.id.iv_inbound);

        iv_outbound = findViewById(R.id.iv_outbound);
        iv_inventory = findViewById(R.id.iv_inventory);
        iv_first_mile = findViewById(R.id.iv_first_mile);

        iv_inbound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, InboundActivity.class);
                startActivity(i);
            }
        });
        iv_inventory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, InventoryActivity.class);
                startActivity(i);
            }
        });
        iv_outbound.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, OutboundActivity.class);
                startActivity(i);
            }
        });
        iv_first_mile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, FirstMileActivity.class);
                startActivity(i);
            }
        });
        iv_last_mile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, LastMileActivity.class);
                startActivity(i);
            }
        });

    }
}
