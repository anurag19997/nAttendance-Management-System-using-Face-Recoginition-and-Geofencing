package com.example.dtdcdeliveryapp;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.dtdcdeliveryapp.Adapters.AssignedPickupAdapter;
import com.example.dtdcdeliveryapp.Adapters.CompletePickupAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class VendorPickupActivity extends AppCompatActivity {
    ArrayList<PickupInfo> completedPickupInfos,partialPickupInfo;
    public static final int JOB_ID = 123;
    int PrsId;
    TextView tv_client, tv_address, tv_mf_id, tv_distance;
    public static final String TAG = "VendorPickupActivity";
    ArrayList<PickupInfo> pickupInfos;
    Button btn_pickup;
    private static final String BASE_URL = "http://neha.isopronto.com:82/api/isopronto/GetPrsDetailsForBiker";
    RecyclerView rv_assigned_pickups, rv_complete_pickups;
    ArrayList<CompletePickup> completePickups;
    ArrayList<AssignedPickup> assignedPickups;
    CompletePickupAdapter completePickupAdapter;
    AssignedPickupAdapter assignedPickupAdapter;
    Boolean isPicked;
    SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.something);
        completedPickupInfos = new ArrayList<>();
        pickupInfos = new ArrayList<>();
        btn_pickup = findViewById(R.id.btn_pickup);
        tv_client = findViewById(R.id.tv_client);
        tv_address = findViewById(R.id.tv_address);
        tv_mf_id = findViewById(R.id.tv_mf_id);
        rv_complete_pickups = findViewById(R.id.rv_complete_pickups);
        rv_assigned_pickups = findViewById(R.id.rv_assigned_pickups);
        assignedPickups = new ArrayList<>();
        completePickups = new ArrayList<>();
        completePickupAdapter = new CompletePickupAdapter(completePickups);
        assignedPickupAdapter = new AssignedPickupAdapter(assignedPickups);
        tv_distance = findViewById(R.id.tv_distance);
         sharedPreferences = getSharedPreferences("SharedPreferences",MODE_PRIVATE);
        Float distance = sharedPreferences.getFloat("distance",0);
        Log.d(TAG, "onCreate: " + distance);
        tv_distance.setText(String.valueOf(distance));
        String response = "[{\"AssignToBikerId\":0,\"AssignToBikerName\":\"\",\"PrsId\":3,\"PrsNo\":\"PRS/1920/0000003\"," +
                "\"PrsDate\":\"05/06/2019 00:00:00\",\"MerchantId\":0,\"MerchantName\":\"surya\",\"MerchantAddress\":\"dwarka\"," +
                "\"TrackingNo\":\"12\",\"ManifestId\":0,\"PinCode\":\"0\",\"MerchantCity\":\"\",\"SkuId\":1,\"SkuCode\":\"A00000001\"," +
                "\"SkuDescription\":\"AUDI\"},{\"AssignToBikerId\":0,\"AssignToBikerName\":\"\",\"PrsId\":4,\"PrsNo\":\"PRS/1920/0000004\"," +
                "\"PrsDate\":\"05/06/2019 00:00:00\",\"MerchantId\":0,\"MerchantName\":\"Tushar\",\"MerchantAddress\":\"dwarka\"," +
                "\"TrackingNo\":\"12\",\"ManifestId\":0,\"PinCode\":\"0\",\"MerchantCity\":\"\",\"SkuId\":1,\"SkuCode\":\"A00000001\"," +
                "\"SkuDescription\":\"AUDI\"},{\"AssignToBikerId\":0,\"AssignToBikerName\":\"\",\"PrsId\":5,\"PrsNo\":\"PRS/1920/0000005\"," +
                "\"PrsDate\":\"05/06/2019 00:00:00\",\"MerchantId\":1,\"MerchantName\":\"Anurag\",\"MerchantAddress\":\"dwarka\"," +
                "\"TrackingNo\":\"12\",\"ManifestId\":0,\"PinCode\":\"0\",\"MerchantCity\":\"\",\"SkuId\":1,\"SkuCode\":\"A00000001\",\"SkuDescription\":\"AUDI\"}]";
        File dataDir = ContextCompat.getDataDir(VendorPickupActivity.this);
        File completedPickupFile = new File(dataDir, "myfile.txt");
        try {

            FileInputStream fis = new FileInputStream(completedPickupFile);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);

            StringBuilder sb = new StringBuilder();
            String buffer = br.readLine();
            while (buffer != null) {
                sb.append(buffer);
                buffer = br.readLine();
            }

            String text = sb.toString();
            completedPickupInfos = pickupInfoList(text);
            Log.d(TAG, "onCreate: " + text);

        } catch (FileNotFoundException fnfe) {
            Toast.makeText(VendorPickupActivity.this, "File not found", Toast.LENGTH_SHORT).show();
        } catch (IOException ioe) {
            Toast.makeText(VendorPickupActivity.this, "Error while reading file", Toast.LENGTH_SHORT).show();
        }

        File myFile = new File(dataDir, "file.txt");
        if(myFile.exists()){
            myFile.delete();
        }
        try {
            FileOutputStream fos = new FileOutputStream(myFile, true);
            fos.write(response.getBytes());

        } catch (FileNotFoundException fnfe) {
            Toast.makeText(VendorPickupActivity.this, "File not found", Toast.LENGTH_SHORT).show();
        } catch (IOException ioe) {
            Toast.makeText(VendorPickupActivity.this, "Error while writing file", Toast.LENGTH_SHORT).show();
        }
        pickupInfos = pickupInfoList(response);
        // Scheduling a job to resync the response getting from api
//        JobScheduler jobScheduler = (JobScheduler) getSystemService(JOB_SCHEDULER_SERVICE);
//        JobInfo jobInfo = new JobInfo.Builder(JOB_ID, new ComponentName(this,  ResyncJob.class))
//                .setPeriodic(1200000)
//                .setPersisted(true)
//                .build();
//        jobScheduler.schedule(jobInfo);
//        JSONArray jsonArr = new JSONArray();
//        try {
//            jsonArr = new JSONArray(response);
//            for(int i = 0 ; i < jsonArr.length(); i++){
//                JSONObject object = jsonArr.getJSONObject(i);
//                int AssignToBikeId = object.getInt("AssignToBikerId");
//                String AssignToBikername = object.getString("AssignToBikerName");
//                int PrsId = object.getInt("PrsId");
//                String PrsNo = object.getString("PrsNo");
//                String PrsDate = object.getString("PrsDate");
//                int MerchantId = object.getInt("MerchantId");
//                String MerchantName = object.getString("MerchantName");
//                String MerchantAddress = object.getString("MerchantAddress");
//                String TrackingNo = object.getString("TrackingNo");
//                int ManifestId = object.getInt("ManifestId");
//                String PinCode = object.getString("PinCode");
//                String MerchantCity = object.getString("MerchantCity");
//                int SkuId = object.getInt("SkuId");
//                String SkuCode = object.getString("SkuCode");
//                String SkuDescription = object.getString("SkuDescription");
//                PickupInfo pickupInfo = new PickupInfo(AssignToBikeId,AssignToBikername,PrsId,PrsNo,PrsDate,MerchantId,MerchantName,MerchantAddress,
//                        TrackingNo,ManifestId,PinCode,MerchantCity,SkuId,SkuCode,SkuDescription);
//                pickupInfos.add(pickupInfo);
//
//            }
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//        Log.d(TAG, "onCreate: "+pickupInfos.size());

        pickupsGenerator(pickupInfos);
        CompletepickupsGenerator(completedPickupInfos);
        rv_assigned_pickups.setLayoutManager(new LinearLayoutManager(
                VendorPickupActivity.this,
                LinearLayoutManager.VERTICAL,
                false
        ));
        rv_complete_pickups.setLayoutManager(new LinearLayoutManager(
                VendorPickupActivity.this,
                LinearLayoutManager.VERTICAL,
                false
        ));

        rv_assigned_pickups.setAdapter(assignedPickupAdapter);
        rv_complete_pickups.setAdapter(completePickupAdapter);
        rv_assigned_pickups.addOnItemTouchListener(new RecyclerTouchListener(VendorPickupActivity.this,
                rv_assigned_pickups,
                new RecyclerTouchListener.ClickListener() {
                    @Override
                    public void onClick(View view, int position) {
                       PickupInfo pickupInfo = pickupInfos.get(position);
                       tv_address.setText(pickupInfo.getMerchantAddress());
                       tv_client.setText(pickupInfo.getMerchantName());
                       PrsId = pickupInfo.getPrsId();
                       isPicked = pickupInfo.isPicked();


                        //


                       //tv_mf_id.setText(pickupInfo.getManifestId());
                    }

                    @Override
                    public void onLongClick(View view, int position) {

                    }
                }));
        rv_complete_pickups.addOnItemTouchListener(new RecyclerTouchListener(VendorPickupActivity.this,
                        rv_complete_pickups, new RecyclerTouchListener.ClickListener() {
                    @Override
                    public void onClick(View view, int position) {
                        PickupInfo pickupInfo = completedPickupInfos.get(position);
                        final AlertDialog alertDialog = new AlertDialog.Builder(VendorPickupActivity.this)
                                .setTitle("Information : ")
                                .setMessage("Client : " + pickupInfo.getMerchantName()+"\n"+
                                        "Address : " + pickupInfo.getMerchantAddress()+"\n"+
                                        "Prs Date : " + pickupInfo.getPrsDate())
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                    }
                                })
                                .create();
                        alertDialog.show();
                    }

                    @Override
                    public void onLongClick(View view, int position) {

                    }
                }));

        btn_pickup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(tv_client.getText().toString().length()>0&& !isPicked){
                    int perm = ContextCompat.checkSelfPermission(VendorPickupActivity.this,Manifest.permission.ACCESS_COARSE_LOCATION);
                    if(perm == PackageManager.PERMISSION_GRANTED){
                        Intent i = new Intent(VendorPickupActivity.this, PickupActivity.class);
                        i.putExtra("PrsId", PrsId);
                        startActivity(i);
                    }else{
                        ActivityCompat.requestPermissions(VendorPickupActivity.this,
                                new String[] {
                                        Manifest.permission.ACCESS_COARSE_LOCATION,
                                        Manifest.permission.ACCESS_FINE_LOCATION
                                },10001);
                        btn_pickup.callOnClick();
                    }

                }else if(isPicked){
                    Toast.makeText(VendorPickupActivity.this, "Already Picked", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(VendorPickupActivity.this, "Please Select a Order", Toast.LENGTH_SHORT).show();
                }

            }
        });


//        Gson gson = new Gson();
//        PickupInfo pickupInfo = gson.fromJson(response, PickupInfo.class);
//        Log.d(TAG, "onCreate: "+pickupInfo.getPrsNo());
//        try {
//            makeNetworkCall(BASE_URL);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }


    }
    public void makeNetworkCall(String url) throws IOException {
        final OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                //Show a toast
                Log.d(TAG, "onFailure: " + e.toString());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                //This method does not run on the Main Thread
                String result = response.body().string();
                Log.d(TAG, "onResponse: "+ result);
            }
        });
    }
    public void pickupsGenerator(ArrayList<PickupInfo> pickupInfoArrayList){
        for(int i = 0 ; i < pickupInfoArrayList.size() ; i++){
            PickupInfo pickupInfo = pickupInfoArrayList.get(i);
            AssignedPickup assignedPickup = new AssignedPickup(pickupInfo.getMerchantName(), pickupInfo.getPrsDate());
            assignedPickups.add(assignedPickup);
            assignedPickupAdapter.notifyDataSetChanged();
        }
    }
    public void CompletepickupsGenerator(ArrayList<PickupInfo> pickupInfoArrayList){
        for(int i = 0 ; i < pickupInfoArrayList.size() ; i++){
            PickupInfo pickupInfo = pickupInfoArrayList.get(i);
            CompletePickup completePickup = new CompletePickup(pickupInfo.getMerchantName(), pickupInfo.getPrsDate(), "Pickup Done");
            completePickups.add(completePickup);
            completePickupAdapter.notifyDataSetChanged();
        }
    }
    public ArrayList<PickupInfo> pickupInfoList(String response){
        ArrayList<PickupInfo> pickupInfoList =new ArrayList<>();
        JSONArray jsonArr = new JSONArray();
        try {
            jsonArr = new JSONArray(response);
            for(int i = 0 ; i < jsonArr.length(); i++){
                JSONObject object = jsonArr.getJSONObject(i);
                int AssignToBikeId = object.getInt("AssignToBikerId");
                String AssignToBikername = object.getString("AssignToBikerName");
                int PrsId = object.getInt("PrsId");
                String PrsNo = object.getString("PrsNo");
                String PrsDate = object.getString("PrsDate");
                int MerchantId = object.getInt("MerchantId");
                String MerchantName = object.getString("MerchantName");
                String MerchantAddress = object.getString("MerchantAddress");
                String TrackingNo = object.getString("TrackingNo");
                int ManifestId = object.getInt("ManifestId");
                String PinCode = object.getString("PinCode");
                String MerchantCity = object.getString("MerchantCity");
                int SkuId = object.getInt("SkuId");
                String SkuCode = object.getString("SkuCode");
                String SkuDescription = object.getString("SkuDescription");
                Boolean isPicked = false;
                Log.d(TAG, "pickupInfoList: "+completedPickupInfos.size());
                for(int j = 0; j<completedPickupInfos.size();j++){
                    if(completedPickupInfos.get(j).getPrsId()==PrsId){
                        Log.d(TAG, "pickupInfoList: " +completedPickupInfos.get(j).getPrsId());
                        isPicked = true;
                    }
                }
                Log.d(TAG, "pickupInfoList: " + isPicked);
                PickupInfo pickupInfo = new PickupInfo(AssignToBikeId,AssignToBikername,PrsId,PrsNo,PrsDate,MerchantId,MerchantName,MerchantAddress,
                        TrackingNo,ManifestId,PinCode,MerchantCity,SkuId,SkuCode,SkuDescription,isPicked, BitmapFactory.decodeResource(getResources(),
                        R.drawable.iconfinder_bitmap_image_52900), "",false, new ArrayList<String>(),new ArrayList<String>());
                if(!pickupInfo.isPicked()) {
                    pickupInfoList.add(pickupInfo);
                }

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return pickupInfoList;
    }

//    @Override
//    protected void onResume() {
//        super.onResume();
//        File dataDir = ContextCompat.getDataDir(VendorPickupActivity.this);
//        File completedPickupFile = new File(dataDir, "myfile.txt");
//        try {
//
//            FileInputStream fis = new FileInputStream(completedPickupFile);
//            InputStreamReader isr = new InputStreamReader(fis);
//            BufferedReader br = new BufferedReader(isr);
//
//            StringBuilder sb = new StringBuilder();
//            String buffer = br.readLine();
//            while (buffer != null) {
//                sb.append(buffer);
//                buffer = br.readLine();
//            }
//
//            String text = sb.toString();
//            completedPickupInfos = pickupInfoList(text);
//            Log.d(TAG, "onCreate: " + text);
//            CompletepickupsGenerator(completedPickupInfos);
//
//        } catch (FileNotFoundException fnfe) {
//            Toast.makeText(VendorPickupActivity.this, "File not found", Toast.LENGTH_SHORT).show();
//        } catch (IOException ioe) {
//            Toast.makeText(VendorPickupActivity.this, "Error while reading file", Toast.LENGTH_SHORT).show();
//        }
//    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i =new Intent(VendorPickupActivity.this, FirstMileActivity.class);
        startActivity(i);
    }
}
