package com.example.dtdcdeliveryapp

import android.graphics.Bitmap
import java.util.*
import kotlin.collections.ArrayList

data class PickupInfo(val AssignToBikerId : Int,
                      val AssignToBikerName:String,
                      val PrsId:Int,val PrsNo:String,
                      val PrsDate:String,
                      val MerchantId:Int,
                      val MerchantName:String,
                      val MerchantAddress:String,
                      val TrackingNo:String,
                      val ManifestId:Int,
                      val PinCode:String,
                      val MerchantCity:String,
                      val SkuId:Int,
                      val SkuCode:String,
                      val SkuDescription:String,
                      var isPicked : Boolean,
                      var bitmap: Bitmap,
                      var remark : String,
                      var isValid : Boolean,
                      var validShipments : ArrayList<String>,
                      var invalidShipments : ArrayList<String>)