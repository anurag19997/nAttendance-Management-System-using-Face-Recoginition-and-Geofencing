package com.example.dtdcdeliveryapp;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.zxing.Result;

import java.util.ArrayList;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class UsnScannerActivity extends AppCompatActivity implements ZXingScannerView.ResultHandler {
    private ZXingScannerView scannerView;
    FirebaseDatabase database;
    DatabaseReference myRef;
    ArrayList<String> list;
    String order_no;
    Boolean isCorrect;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        Intent i = getIntent();
        list = i.getStringArrayListExtra("lots");
        order_no = i.getStringExtra("order_no");
//        binCode = i.getStringExtra("binCode");
//        isCorrect = false;
        scannerView = new ZXingScannerView(this);
        setContentView(scannerView);
        scannerView.setResultHandler(this);
        scannerView.startCamera();
    } @Override
    public void handleResult(Result result) {
        final String myResult = result.getText();
        Log.d("QRCodeScanner", result.getText());
        Log.d("QRCodeScanner", result.getBarcodeFormat().toString());
        list.add(myResult);

        Intent i = new Intent(UsnScannerActivity.this, GoDeliveryPickingActivity.class);
//            i.putExtra("isCorrect", isCorrect);
        i.putExtra("lots", list);
        i.putExtra("order_no", order_no);
        i.putExtra("isCorrect", true);
        startActivity(i);
//            if (binCode == null) {

    }

}
