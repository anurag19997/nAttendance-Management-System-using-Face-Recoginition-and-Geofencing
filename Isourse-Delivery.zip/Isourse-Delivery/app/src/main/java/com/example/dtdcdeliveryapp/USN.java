package com.example.dtdcdeliveryapp;

import java.util.HashMap;

public class USN {
    String binCode;
    String sku;
    HashMap<String, Boolean> hashMap;

    public USN(String binCode, String sku, HashMap<String, Boolean> hashMap) {
        this.binCode = binCode;
        this.sku = sku;
        this.hashMap = hashMap;
    }

    public String getBinCode() {
        return binCode;
    }

    public void setBinCode(String binCode) {
        this.binCode = binCode;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public HashMap<String, Boolean> getHashMap() {
        return hashMap;
    }

    public void setHashMap(HashMap<String, Boolean> hashMap) {
        this.hashMap = hashMap;
    }
}
