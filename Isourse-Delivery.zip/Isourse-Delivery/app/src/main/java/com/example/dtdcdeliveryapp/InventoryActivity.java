package com.example.dtdcdeliveryapp;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

import com.example.dtdcdeliveryapp.Adapters.TabAdapter;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {
    RecyclerView rv_inventory;
    ArrayList<Tab> tabs;
    TabAdapter tabAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        rv_inventory = findViewById(R.id.rv_inventory);
        tabs = new ArrayList<>();
        tabAdapter = new TabAdapter(tabs);
        tabGenerator(5);

        rv_inventory.setLayoutManager(new GridLayoutManager(
                this,
                1,
                LinearLayoutManager.VERTICAL,
                false
        ));
        rv_inventory.setAdapter(tabAdapter);
        rv_inventory.addOnItemTouchListener(new RecyclerTouchListener(InventoryActivity.this, rv_inventory, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                switch (position){
                    case 0 :
                        Intent i0 = new Intent(InventoryActivity.this, InventoryMoveActivity.class);
                        startActivity(i0);
                        break;
                    case 2 :
                        Intent i2 = new Intent(InventoryActivity.this, InventoryAdjustmentActivity.class);
                        startActivity(i2);
                        break;

                }
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

//        LinearLayout inventory_move = findViewById(R.id.inventory_move);
//        LinearLayout inventory_adjustment = findViewById(R.id.inventory_adjustment);
//        inventory_adjustment.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i = new Intent(InventoryActivity.this, InventoryAdjustmentActivity.class);
//                startActivity(i);
//            }
//        });
//        inventory_move.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i = new Intent(InventoryActivity.this, InventoryMoveActivity.class);
//                startActivity(i);
//            }
//        });
    }
    public void tabGenerator(int n){

        Tab tab1 = new Tab("Inventory Move", R.drawable.inventory_move_image, 6);
        tabs.add(tab1);
        Tab tab2 = new Tab("Inventory Search", R.drawable.inventory_search_image, 7);
        tabs.add(tab2);
        Tab tab3 = new Tab("Inventory Adjustment", R.drawable.inventory_adjustment_image, 8);
        tabs.add(tab3);
        Tab tab4 = new Tab("Stock Count", R.drawable.inventory,9);
        tabs.add(tab4);
        tabAdapter.notifyDataSetChanged();

    }
}
