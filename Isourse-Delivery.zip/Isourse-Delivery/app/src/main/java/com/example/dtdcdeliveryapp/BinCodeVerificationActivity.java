package com.example.dtdcdeliveryapp;

import android.content.DialogInterface;
import android.content.Intent;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.google.zxing.Result;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class BinCodeVerificationActivity extends AppCompatActivity implements ZXingScannerView.ResultHandler{
    private ZXingScannerView scannerView;
    String binCode;
    Boolean isCorrect;
    String order_no;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bin_code_verification);
        Intent i = getIntent();
        isCorrect = i.getBooleanExtra("isCorrect", false);
        binCode = i.getStringExtra("binCode");
        order_no = i.getStringExtra("order_no");

        scannerView = new ZXingScannerView(this);
        setContentView(scannerView);
        scannerView.setResultHandler(this);
        scannerView.startCamera();
    }
    @Override
    public void handleResult(Result result) {
        final String myResult = result.getText();
        Log.d("QRCodeScanner", result.getText());
        Log.d("QRCodeScanner", result.getBarcodeFormat().toString());
        if(binCode.equals(myResult)){
            Intent i = new Intent(BinCodeVerificationActivity.this, GoDeliveryPickingActivity.class);
            i.putExtra("isCorrect", true );
            i.putExtra("order_no", order_no);
            startActivity(i);
        }else{
           // setContentView(R.layout.activity_bin_code_verification);
            AlertDialog alertDialog = new AlertDialog.Builder(BinCodeVerificationActivity.this)
                    .setTitle("Alert !!")
                    .setMessage("Bin Code is Incorrect")
                    .setCancelable(false)
                    .setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            setContentView(scannerView);
                            scannerView.setResultHandler(BinCodeVerificationActivity.this);
                            scannerView.startCamera();
                        }
                    })
                    .setNegativeButton("Go Back", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent i = new Intent(BinCodeVerificationActivity.this, GoDeliveryPickingActivity.class);
                            i.putExtra("isCorrect", isCorrect);
                            i.putExtra("order_no", order_no);
                            startActivity(i);
                        }
                    })
                    .create();
            alertDialog.show();
        }



//            if (binCode == null) {

    }
}
