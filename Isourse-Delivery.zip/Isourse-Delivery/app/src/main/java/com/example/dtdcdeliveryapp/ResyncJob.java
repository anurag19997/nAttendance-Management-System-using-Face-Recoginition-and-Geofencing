package com.example.dtdcdeliveryapp;

import android.app.job.JobParameters;
import android.app.job.JobService;

import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AlertDialog;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class ResyncJob extends JobService {
    public static final String TAG = "ResyncJob";

    @Override
    public boolean onStartJob(JobParameters jobParameters) {
        String url = "http://neha.isopronto.com:82/api/isopronto/GetPrsDetailsForBiker";
        try {
            makeNetworkCall(url);
        } catch (IOException e) {
            e.printStackTrace();
        }
        Toast.makeText(getBaseContext(),"Resyncing done", Toast.LENGTH_SHORT).show();

        return true;
    }

    @Override
    public boolean onStopJob(JobParameters jobParameters) {
        return false;
    }
    public void makeNetworkCall(String url) throws IOException {
        final OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                //Show a toast
                Log.d(TAG, "onFailure: " + e.toString());
                String Response = "[{\"AssignToBikerId\":0,\"AssignToBikerName\":\"\",\"PrsId\":3,\"PrsNo\":\"PRS/1920/0000003\"," +
                        "\"PrsDate\":\"05/06/2019 00:00:00\",\"MerchantId\":0,\"MerchantName\":\"surya\",\"MerchantAddress\":\"dwarka\"," +
                        "\"TrackingNo\":\"12\",\"ManifestId\":0,\"PinCode\":\"0\",\"MerchantCity\":\"\",\"SkuId\":1,\"SkuCode\":\"A00000001\"," +
                        "\"SkuDescription\":\"AUDI\"},{\"AssignToBikerId\":0,\"AssignToBikerName\":\"\",\"PrsId\":4,\"PrsNo\":\"PRS/1920/0000004\"," +
                        "\"PrsDate\":\"05/06/2019 00:00:00\",\"MerchantId\":0,\"MerchantName\":\"Tushar\",\"MerchantAddress\":\"dwarka\"," +
                        "\"TrackingNo\":\"12\",\"ManifestId\":0,\"PinCode\":\"0\",\"MerchantCity\":\"\",\"SkuId\":1,\"SkuCode\":\"A00000001\"," +
                        "\"SkuDescription\":\"AUDI\"},{\"AssignToBikerId\":0,\"AssignToBikerName\":\"\",\"PrsId\":5,\"PrsNo\":\"PRS/1920/0000005\"," +
                        "\"PrsDate\":\"05/06/2019 00:00:00\",\"MerchantId\":1,\"MerchantName\":\"Anurag\",\"MerchantAddress\":\"dwarka\"," +
                        "\"TrackingNo\":\"12\",\"ManifestId\":0,\"PinCode\":\"0\",\"MerchantCity\":\"\",\"SkuId\":1,\"SkuCode\":\"A00000001\",\"SkuDescription\":\"AUDI\"}]";
                Log.d(TAG, "onFailure: " + Response);
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                //This method does not run on the Main Thread
                String result = response.body().string();

                Log.d(TAG, "onResponse: "+ result);
                File dataDir = ContextCompat.getDataDir(getApplicationContext());
                File myFile = new File(dataDir, "file.txt");
                if(myFile.exists()){
                    myFile.delete();
                }
                try {
                    FileOutputStream fos = new FileOutputStream(myFile, true);
                    fos.write(result.getBytes());

                } catch (FileNotFoundException fnfe) {
                    Toast.makeText(getApplicationContext(), "File not found", Toast.LENGTH_SHORT).show();
                } catch (IOException ioe) {
                    Toast.makeText(getApplicationContext(), "Error while writing file", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
