package com.example.dtdcdeliveryapp;

public class PutawayInfo {
    private static int totalCount;
    private int no;
    private String bincode;
    private String modeOfPutaway;
    private String info;

    public static int getTotalCount() {
        return totalCount;
    }

    public static void setTotalCount(int totalCount) {
        PutawayInfo.totalCount = totalCount;
    }

    public PutawayInfo() {
    }

    public int getNo() {
        return no;
    }

    public PutawayInfo(int no, String bincode, String modeOfPutaway, String info) {
        this.no = no;
        this.bincode = bincode;
        this.modeOfPutaway = modeOfPutaway;
        this.info = info;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public String getBincode() {
        return bincode;
    }

    public void setBincode(String bincode) {
        this.bincode = bincode;
    }

    public String getModeOfPutaway() {
        return modeOfPutaway;
    }

    public void setModeOfPutaway(String modeOfPutaway) {
        this.modeOfPutaway = modeOfPutaway;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}
