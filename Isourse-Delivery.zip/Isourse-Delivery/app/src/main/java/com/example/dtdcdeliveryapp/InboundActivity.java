package com.example.dtdcdeliveryapp;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

import com.example.dtdcdeliveryapp.Adapters.TabAdapter;

import java.util.ArrayList;

public class InboundActivity extends AppCompatActivity {
    RecyclerView rv_inbound;
    ArrayList<Tab> tabs;
    TabAdapter tabAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inbound);
        rv_inbound = findViewById(R.id.rv_inbound);
        tabs = new ArrayList<>();
        tabAdapter = new TabAdapter(tabs);
        tabGenerator(5);

        rv_inbound.setLayoutManager(new GridLayoutManager(
                this,
                1,
                LinearLayoutManager.VERTICAL,
                false
        ));
        rv_inbound.setAdapter(tabAdapter);
        rv_inbound.addOnItemTouchListener(new RecyclerTouchListener(InboundActivity.this, rv_inbound, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                switch (position){
                    case 0 :
//                        Intent i0 = new Intent(InboundActivity.this, Po.class);
//                        startActivity(i0);
//                        break;
                    case 1 :
//                        Intent i1 = new Intent(InboundActivity.this, .class);
//                        startActivity(i1);
//                        break;
                    case 2 :
                        Intent i2 = new Intent(InboundActivity.this, PutawayActivity.class);
                        startActivity(i2);
                        break;
                    case 3 :
                        Intent i3 = new Intent(InboundActivity.this, DirectedPutawayActivity.class);
                        startActivity(i3);
                        break;

                }
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));
//        iv_directed_putaway = findViewById(R.id.iv_directed_putaway);
//        iv_directed_putaway.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i = new Intent(InboundActivity.this, DirectedPutawayActivity.class);
//                startActivity(i);
//            }
//        });
    }
    public void tabGenerator(int n){

        Tab tab1 = new Tab("PO Inbound", R.drawable.po_inbound, 1);
        tabs.add(tab1);
        Tab tab2 = new Tab("Return Inbound", R.drawable.return_inbound, 2);
        tabs.add(tab2);
        Tab tab3 = new Tab("Putaway", R.drawable.putaway_image, 3);
        tabs.add(tab3);
        Tab tab4 = new Tab("Directed Putaway", R.drawable.directed_putaway,4);
        tabs.add(tab4);
        tabAdapter.notifyDataSetChanged();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(InboundActivity.this, Main3Activity.class);
        startActivity(i);
    }
}
