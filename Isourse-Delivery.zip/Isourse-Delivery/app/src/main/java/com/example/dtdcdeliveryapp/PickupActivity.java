package com.example.dtdcdeliveryapp;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationListener;
import android.net.Uri;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.gcacace.signaturepad.views.SignaturePad;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class PickupActivity extends AppCompatActivity
        implements GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener, LocationListener
       {
           Float tvDistance;
    EditText et_remark;
    public static final String TAG = "PickupActivity";
    ListView rv_invalid_shipments, rv_valid_shipments;
    SignaturePad signaturePad;
    Button saveButton, clearButton;
    ArrayList<String> validShipments;
    ArrayList<String> invalidShipments;
    ArrayList<PickupInfo> pickupInfos;
    ArrayList<PickupInfo> completedPickupInfos;
    int PrsId;
    PickupInfo pickupInfo;
    TextView tv_client_name;
    // Distance Calculation
    SharedPreferences sharedPreferences;
    Float startLat, startLong;
    TextView tv_distance;
    private Location location;
    private TextView locationTv;
    private GoogleApiClient googleApiClient;
    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    private LocationRequest locationRequest;
    private static final long UPDATE_INTERVAL = 5000, FASTEST_INTERVAL = 5000; // = 5 seconds
    // lists for permissions
    float[] results;
    private ArrayList<String> permissionsToRequest;
    private ArrayList<String> permissionsRejected = new ArrayList<>();
    private ArrayList<String> permissions = new ArrayList<>();
    // integer for permissions results request
    private static final int ALL_PERMISSIONS_RESULT = 1011;
    Button btn_pickup , btn_navigate;
    EditText et_shipment_id;
    Button btn_done , btn_scan;
    Float distance ;
    String startTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pickup);
        tvDistance = (float) 0.0;
        btn_scan = findViewById(R.id.btn_scan);
        btn_navigate = findViewById(R.id.btn_navigate);
        Intent intent = getIntent();
        String result = intent.getStringExtra("result");
        et_remark = findViewById(R.id.et_remark);
        PrsId = intent.getIntExtra("PrsId", 0);
        validShipments = intent.getStringArrayListExtra("validShipments");
        invalidShipments = intent.getStringArrayListExtra("invalidShipments");
        Log.d(TAG, "onCreate: " + PrsId);
        btn_done = findViewById(R.id.btn_done);
        pickupInfos = new ArrayList<>();
        et_shipment_id = findViewById(R.id.et_shipment_id);
        signaturePad = findViewById(R.id.signaturePad);
        saveButton = findViewById(R.id.saveButton);
        clearButton = findViewById(R.id.clearButton);
        rv_invalid_shipments = findViewById(R.id.rv_invalid_shipments);
        rv_valid_shipments = findViewById(R.id.rv_valid_shipments);
        tv_client_name = findViewById(R.id.tv_client_name);
        if(validShipments==null){
            validShipments = new ArrayList<>();
        }
       if(invalidShipments==null) {
           invalidShipments = new ArrayList<>();
       }
        completedPickupInfos = new ArrayList<>();
//        String startLatitude = "0";
//        String startLongitude = "0";
//        String destLatitude = "0";
//        String destLongitude = "0";

       // https://dev.virtualearth.net/REST/v1/Routes/DistanceMatrix?origins=47.6044,-122.3345;47.6731,-122.1185;47.6149,-122.1936&destinations=45.5347,-122.6231;47.4747,-122.2057
        // &travelMode=driving&startTime=2017-06-15T13:00:00-07:00&
        // key=AkhBUUbuh2bBepI13d2oLeEjxcR219PhmjfwnJOSrXATmcKuX2U6Adih6Mev7TRd


        et_shipment_id.setText(result);
        File dataDir = ContextCompat.getDataDir(PickupActivity.this);
        File myFile = new File(dataDir, "file.txt");
        try {

            FileInputStream fis = new FileInputStream(myFile);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);

            StringBuilder sb = new StringBuilder();
            String buffer = br.readLine();
            while (buffer != null) {
                sb.append(buffer);
                buffer = br.readLine();
            }

            String text = sb.toString();
            pickupInfos = pickupInfoList(text);
            Log.d(TAG, "onCreate: " + text);

        } catch (FileNotFoundException fnfe) {
            Toast.makeText(PickupActivity.this, "File not found", Toast.LENGTH_SHORT).show();
        } catch (IOException ioe) {
            Toast.makeText(PickupActivity.this, "Error while reading file", Toast.LENGTH_SHORT).show();
        }
        File completedPickupFile = new File(dataDir, "myfile.txt");
        try {

            FileInputStream fis = new FileInputStream(completedPickupFile);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);

            StringBuilder sb = new StringBuilder();
            String buffer = br.readLine();
            while (buffer != null) {
                sb.append(buffer);
                buffer = br.readLine();
            }

            String text = sb.toString();
            completedPickupInfos = pickupInfoList(text);
            Log.d(TAG, "onCreate: " + text);

        } catch (FileNotFoundException fnfe) {
            Toast.makeText(PickupActivity.this, "File not found", Toast.LENGTH_SHORT).show();
        } catch (IOException ioe) {
            Toast.makeText(PickupActivity.this, "Error while reading file", Toast.LENGTH_SHORT).show();
        }
        for (int i = 0; i < pickupInfos.size(); i++) {
            if (PrsId != 0 && pickupInfos.get(i).getPrsId() == PrsId) {
                pickupInfo = pickupInfos.get(i);
                if(pickupInfo.isPicked()){
                    btn_done.setEnabled(false);
                }
                tv_client_name.setText(pickupInfo.getMerchantName());
            }
        }
        final ArrayAdapter<String> validShipmentAdapter = new ArrayAdapter<>(PickupActivity.this,
                android.R.layout.simple_list_item_1, validShipments);

        rv_valid_shipments.setAdapter(validShipmentAdapter);
        final ArrayAdapter<String> invalidShipmentAdapter = new ArrayAdapter<>(PickupActivity.this,
                android.R.layout.simple_list_item_1, invalidShipments);

        rv_invalid_shipments.setAdapter(invalidShipmentAdapter);


        saveButton.setEnabled(false);
        clearButton.setEnabled(false);


        signaturePad.setOnSignedListener(new SignaturePad.OnSignedListener() {
            @Override
            public void onStartSigning() {

            }

            @Override
            public void onSigned() {

                saveButton.setEnabled(true);
                clearButton.setEnabled(true);
            }

            @Override
            public void onClear() {
                saveButton.setEnabled(false);
                clearButton.setEnabled(false);
            }
        });

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //write code for saving the signature here
                if(pickupInfo!=null){
                pickupInfo.setBitmap(signaturePad.getSignatureBitmap());
                pickupInfo.setRemark(et_remark.getText().toString());
                pickupInfo.setPicked(true);
                Gson gson = new Gson();
                completedPickupInfos.add(pickupInfo);
                String json = gson.toJson(completedPickupInfos);
                Log.d(TAG, "onClick: "+ json);
                File dataDir = ContextCompat.getDataDir(PickupActivity.this);
                File completedPickuFile = new File(dataDir, "myfile.txt");
                if(completedPickuFile.exists()){
                    completedPickuFile.delete();
                }

                try {
                    FileOutputStream fos = new FileOutputStream(completedPickuFile, true);
                    fos.write(json.getBytes());

                } catch (FileNotFoundException fnfe) {
                    Toast.makeText(PickupActivity.this, "File not found", Toast.LENGTH_SHORT).show();
                } catch (IOException ioe) {
                    Toast.makeText(PickupActivity.this, "Error while writing file", Toast.LENGTH_SHORT).show();
                }
                }
                distance = sharedPreferences.getFloat("distance", 0);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putFloat("startLat", 0);
                editor.putFloat("startLong", 0);
                editor.putString("startTime","");
                editor.putFloat("distance", distance+Float.valueOf(tv_distance.getText().toString()));
                Log.d(TAG, "onClick: "+tv_distance.getText());
                editor.apply();
                startLat = sharedPreferences.getFloat("startLat", 0);
                startLong = sharedPreferences.getFloat("startLong", 0);
                //distance = sharedPreferences.getFloat("distance", 0);
                Toast.makeText(PickupActivity.this, "Saved", Toast.LENGTH_SHORT).show();
            }
        });
        btn_scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int perm = ContextCompat.checkSelfPermission(PickupActivity.this, Manifest.permission.CAMERA);
                if(perm == PackageManager.PERMISSION_GRANTED){
                    Intent i= new Intent(PickupActivity.this, ScannerActivity.class);
                    i.putExtra("validShipments",validShipments);
                    i.putExtra("invalidShipments", invalidShipments);
                    i.putExtra("PrsId",PrsId);
                    startActivity(i);
                }else{
                    ActivityCompat.requestPermissions(PickupActivity.this,
                            new String[]{
                                    Manifest.permission.CAMERA
                            },100);
                    btn_scan.callOnClick();
                }

            }
        });

        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signaturePad.clear();
            }
        });
        // Distance calculation
        results = new float[10];
        sharedPreferences= getSharedPreferences("SharedPreferences", MODE_PRIVATE);
        startTime = sharedPreferences.getString("startTime","");
        if(startTime.equals("")){
            startTime = (DateFormat.format("yyyy-MM-ddThh:mm:ss", new java.util.Date()).toString());
        }
        Log.d(TAG, "onCreate: "+ startTime);
        if(et_shipment_id.getText().toString().length()!=0){
            String shipmentId = et_shipment_id.getText().toString();
            if (shipmentId.equals(String.valueOf(pickupInfo.getManifestId()))) {
                validShipments.add(shipmentId);
                validShipmentAdapter.notifyDataSetChanged();
            } else {
                invalidShipments.add(shipmentId);
                invalidShipmentAdapter.notifyDataSetChanged();
            }
        }
        btn_done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pickupInfo != null) {
                    String shipmentId = et_shipment_id.getText().toString();
                    if (shipmentId.equals(String.valueOf(pickupInfo.getManifestId()))) {
                        validShipments.add(shipmentId);
                        validShipmentAdapter.notifyDataSetChanged();
                    } else {
                        invalidShipments.add(shipmentId);
                        invalidShipmentAdapter.notifyDataSetChanged();
                    }
                }

//                Log.d(TAG, "onClick: " +"startLat :" +startLat +" startLong : " +startLong+ " Distance : " + distance);
            }
        });
        btn_navigate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("google.navigation:q="+pickupInfo.getMerchantAddress()+",New Delhi"));
                startActivity(intent);
            }
        });
        tv_distance =findViewById(R.id.tv_distance);
        // we add permissions we need to request location of the users
        permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
        permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        permissionsToRequest = permissionsToRequest(permissions);
        btn_pickup = findViewById(R.id.btn_pickup);
        startLat = sharedPreferences.getFloat("startLat", 0);
        startLong = sharedPreferences.getFloat("startLong", 0);
       // distance = sharedPreferences.getFloat("distance", 0);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (permissionsToRequest.size() > 0) {
                requestPermissions(permissionsToRequest.toArray(
                        new String[permissionsToRequest.size()]), ALL_PERMISSIONS_RESULT);
            }
        }

        // we build google api client
        googleApiClient = new GoogleApiClient.Builder(this).
                addApi(LocationServices.API).
                addConnectionCallbacks(this).
                addOnConnectionFailedListener(this).build();
    }
    public ArrayList<PickupInfo> pickupInfoList(String response){
        ArrayList<PickupInfo> pickupInfoList =new ArrayList<>();
        JSONArray jsonArr = new JSONArray();
        try {
            jsonArr = new JSONArray(response);
            for(int i = 0 ; i < jsonArr.length(); i++){
                JSONObject object = jsonArr.getJSONObject(i);
                int AssignToBikeId = object.getInt("AssignToBikerId");
                String AssignToBikername = object.getString("AssignToBikerName");
                int PrsId = object.getInt("PrsId");
                String PrsNo = object.getString("PrsNo");
                String PrsDate = object.getString("PrsDate");
                int MerchantId = object.getInt("MerchantId");
                String MerchantName = object.getString("MerchantName");
                String MerchantAddress = object.getString("MerchantAddress");
                String TrackingNo = object.getString("TrackingNo");
                int ManifestId = object.getInt("ManifestId");
                String PinCode = object.getString("PinCode");
                String MerchantCity = object.getString("MerchantCity");
                int SkuId = object.getInt("SkuId");
                String SkuCode = object.getString("SkuCode");
                String SkuDescription = object.getString("SkuDescription");
                PickupInfo pickupInfo = new PickupInfo(AssignToBikeId,AssignToBikername,PrsId,PrsNo,PrsDate,MerchantId,MerchantName,MerchantAddress,
                        TrackingNo,ManifestId,PinCode,MerchantCity,SkuId,SkuCode,SkuDescription,false,
                        BitmapFactory.decodeResource(getResources(),R.drawable.iconfinder_bitmap_image_52900), "", false,
                        new ArrayList<String>(), new ArrayList<String>());
                pickupInfoList.add(pickupInfo);

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return pickupInfoList;
    }
    // Distance Calculation
    private ArrayList<String> permissionsToRequest(ArrayList<String> wantedPermissions) {
        ArrayList<String> result = new ArrayList<>();

        for (String perm : wantedPermissions) {
            if (!hasPermission(perm)) {
                result.add(perm);
            }
        }

        return result;
    }

    private boolean hasPermission(String permission) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
        }

        return true;
    }

    @Override
    protected void onStart() {
        super.onStart();

        if (googleApiClient != null) {
            googleApiClient.connect();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (!checkPlayServices()) {

        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        // stop location updates
        if (googleApiClient != null  &&  googleApiClient.isConnected()) {
            LocationServices.FusedLocationApi.removeLocationUpdates(googleApiClient, new com.google.android.gms.location.LocationListener() {
                @Override
                public void onLocationChanged(Location location) {
//                    android.location.Location.distanceBetween(startLat,startLong,location.getLatitude(),location.getLongitude(),results);
//                    tv_distance.setText(String.valueOf(distance+results[0]/1000));
                    getDistance(startLat.toString(),startLong.toString(),String.valueOf(location.getLatitude()),String.valueOf(location.getLongitude()),startTime);
                    Log.d(TAG, "onLocationChanged: " + results[0]);
                    if(startLat==0 && startLong==0){
                        startLat = (float) location.getLatitude();
                        startLong = (float) location.getLongitude();
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putFloat("startLat", startLat);
                        editor.putFloat("startLong",startLong);
                        editor.apply();
                    }
                }
            });
            googleApiClient.disconnect();
        }
    }

    private boolean checkPlayServices() {
        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
        int resultCode = apiAvailability.isGooglePlayServicesAvailable(this);

        if (resultCode != ConnectionResult.SUCCESS) {
            if (apiAvailability.isUserResolvableError(resultCode)) {
                apiAvailability.getErrorDialog(this, resultCode, PLAY_SERVICES_RESOLUTION_REQUEST);
            } else {
                finish();
            }

            return false;
        }

        return true;
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                &&  ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        // Permissions ok, we get last location
        location = LocationServices.FusedLocationApi.getLastLocation(googleApiClient);

        if (location != null) {

//            android.location.Location.distanceBetween(startLat,startLong,location.getLatitude(),location.getLongitude(),results);
//            tv_distance.setText(String.valueOf(distance+results[0]/1000));
            getDistance(startLat.toString(),startLong.toString(),String.valueOf(location.getLatitude()),String.valueOf(location.getLongitude()),startTime);
            Log.d(TAG, "firstonLocationChanged: " + results[0] );
            if(startLat==0 && startLong==0){
                startLat = (float) location.getLatitude();
                startLong = (float) location.getLongitude();
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putFloat("startLat", startLat);
                editor.putFloat("startLong",startLong);
                editor.apply();
            }
        }

        startLocationUpdates();
    }

    private void startLocationUpdates() {
        locationRequest = new LocationRequest();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(UPDATE_INTERVAL);
        locationRequest.setFastestInterval(FASTEST_INTERVAL);
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                &&  ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "You need to enable permissions to display location !", Toast.LENGTH_SHORT).show();
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient, locationRequest, new com.google.android.gms.location.LocationListener() {
            @Override
            public void onLocationChanged(Location location) {

//                android.location.Location.distanceBetween(startLat,startLong,location.getLatitude(),location.getLongitude(),results);
//                tv_distance.setText(String.valueOf(distance+results[0]/1000));
                getDistance(startLat.toString(),startLong.toString(),String.valueOf(location.getLatitude()),String.valueOf(location.getLongitude()),startTime);
                Log.d(TAG, "onLocationChanged: " + results[0]);
                if(startLat==0 && startLong==0){
                    startLat = (float) location.getLatitude();
                    startLong = (float) location.getLongitude();
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putFloat("startLat", startLat);
                    editor.putFloat("startLong",startLong);
                    editor.apply();
                }

            }
        });
    }

    @Override
    public void onConnectionSuspended(int i) {
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
    }

    @Override
    public void onLocationChanged(Location location) {
        if (location != null) {

//            android.location.Location.distanceBetween(startLat,startLong,location.getLatitude(),location.getLongitude(),results);
//            tv_distance.setText(String.valueOf(distance + results[0]/1000));
            getDistance(startLat.toString(),startLong.toString(),String.valueOf(location.getLatitude()),String.valueOf(location.getLongitude()),startTime);

            Log.d(TAG, "onLocationChanged: " + results[0]);
            if(startLat==0 && startLong==0){
                startLat = (float) location.getLatitude();
                startLong = (float) location.getLongitude();
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putFloat("startLat", startLat);
                editor.putFloat("startLong",startLong);
                editor.apply();
            }
        }
    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String s) {

    }

    @Override
    public void onProviderDisabled(String s) {

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch(requestCode) {
            case ALL_PERMISSIONS_RESULT:
                for (String perm : permissionsToRequest) {
                    if (!hasPermission(perm)) {
                        permissionsRejected.add(perm);
                    }
                }

                if (permissionsRejected.size() > 0) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        if (shouldShowRequestPermissionRationale(permissionsRejected.get(0))) {
                            new AlertDialog.Builder(PickupActivity.this).
                                    setMessage("These permissions are mandatory to get your location. You need to allow them.").
                                    setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                                requestPermissions(permissionsRejected.
                                                        toArray(new String[permissionsRejected.size()]), ALL_PERMISSIONS_RESULT);
                                            }
                                        }
                                    }).setNegativeButton("Cancel", null).create().show();

                            return;
                        }
                    }
                } else {
                    if (googleApiClient != null) {
                        googleApiClient.connect();
                    }
                }

                break;
        }
    }
    // Make Network call to distance matrix api
    public void makeNetworkCallToDistanceMatrixApi(String url) throws IOException{
        final OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                //Show a toast
                Log.d(TAG, "onFailure: " + e.toString());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                //This method does not run on the Main Thread
                String result = response.body().string();
                Log.d(TAG, "onResponse: "+ result);
                Gson gson = new Gson();
                DistanceApiResult apiResult = gson.fromJson(result, DistanceApiResult.class);
                Log.d(TAG, "onResponse: " + apiResult);
                Log.d(TAG, "onResponse: "+apiResult.getResourceSets().get(0).getResources().get(0).getResults().get(0).getTravelDistance());
                tvDistance = apiResult.getResourceSets().get(0).getResources().get(0).getResults().get(0).getTravelDistance();

            }
        });
        tv_distance.setText(String.valueOf(tvDistance));

    }
    public void getDistance(String startLat, String startLong, String destLat, String destLong, String startTime){
        String DistanceUrl = "https://dev.virtualearth.net/REST/v1/Routes/DistanceMatrix?origins="+startLat+","+startLong+"&destinations="+destLat+","+
                destLong+"&travelMode=driving&startTime="+startTime+"&key=AkhBUUbuh2bBepI13d2oLeEjxcR219PhmjfwnJOSrXATmcKuX2U6Adih6Mev7TRd";
       // String url = "https://dev.virtualearth.net/REST/v1/Routes/DistanceMatrix?origins=51.506420135498,-0.127210006117821&destinations=53.7947998046875,-1.54653000831604;51.506420135498,-0.127210006117821;53.4100914001465,-2.9784300327301&travelMode=driving&key=AligBxLI69_mk4fRuQjaZ8lNHervyyz6KqOQKoFRQp_EuJ_30U_IarT2TMy1FMK-&distanceUnit=mile&timeUnit=minutes";
        try {
            makeNetworkCallToDistanceMatrixApi(DistanceUrl);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i = new Intent(PickupActivity.this, VendorPickupActivity.class);
        startActivity(i);
    }
}
