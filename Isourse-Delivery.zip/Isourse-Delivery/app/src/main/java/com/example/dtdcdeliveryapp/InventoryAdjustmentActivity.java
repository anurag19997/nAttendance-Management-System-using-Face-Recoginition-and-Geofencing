package com.example.dtdcdeliveryapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryAdjustmentActivity extends AppCompatActivity {
    RecyclerView rv_lot;
    ArrayList<Lot> lots;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_adjustment);
        lots = new ArrayList<>();
        rv_lot = findViewById(R.id.rv_lot);
        Lot lot1 = new Lot("To Bin : ", "");
        Lot lot2 = new Lot("Avl Qty : ", "");
        lots.add(lot1);
        lots.add(lot2);
        laGenerator(20);
        rv_lot.setLayoutManager(
                new LinearLayoutManager(this,
                        LinearLayoutManager.VERTICAL,
                        false
                ));
        LotAdapter lotAdapter = new LotAdapter(lots);
        rv_lot.setAdapter(lotAdapter);
    }
    public void laGenerator(int n){
        for(int i = 1 ; i <= n; i++){
            String laN = "La" + String.valueOf(i)+" : ";
            lots.add(new Lot(laN, ""));
        }

    }
}
