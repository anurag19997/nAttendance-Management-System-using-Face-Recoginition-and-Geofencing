package com.example.dtdcdeliveryapp

data class AssignedPickup(val title : String, val subTitle : String)