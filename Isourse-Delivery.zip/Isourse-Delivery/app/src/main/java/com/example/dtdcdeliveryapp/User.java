package com.example.dtdcdeliveryapp;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import okhttp3.MediaType;
import okhttp3.ResponseBody;
import okio.BufferedSource;

public class User extends ResponseBody {
    String jsonid;
    String jsonpwd;



    public User(String jsonid, String jsonpwd) {
        this.jsonid = jsonid;
        this.jsonpwd = jsonpwd;
    }

    public User() {
    }

    public String getJsonid() {
        return jsonid;
    }

    public void setJsonid(String jsonid) {
        this.jsonid = jsonid;
    }

    public String getJsonpwd() {
        return jsonpwd;
    }

    public void setJsonpwd(String jsonpwd) {
        this.jsonpwd = jsonpwd;
    }

    @Override
    public long contentLength() {
        return 0;
    }

    @Nullable
    @Override
    public MediaType contentType() {
        return null;
    }

    @NotNull
    @Override
    public BufferedSource source() {
        return null;
    }
}
