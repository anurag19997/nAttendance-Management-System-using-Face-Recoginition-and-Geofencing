package com.example.dtdcdeliveryapp;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.google.zxing.Result;

import java.util.ArrayList;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class ScannerActivity extends AppCompatActivity implements ZXingScannerView.ResultHandler{
    public static final String TAG = "ScannerActivity";
    private ZXingScannerView scannerView;
    int PrsId;
    ArrayList<String> validShipments, invalidShipments;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scanner);
        Intent i = getIntent();
        PrsId = i.getIntExtra("PrsId" , 1000000);
        validShipments = i.getStringArrayListExtra("validShipments");
        invalidShipments = i .getStringArrayListExtra("invalidShipments");
        Log.d(TAG, "onCreate: " + PrsId);
        scannerView = new ZXingScannerView(this);
        setContentView(scannerView);
        scannerView.setResultHandler(this);
        scannerView.startCamera();
    }

    @Override
    public void handleResult(Result result) {
        final String myResult = result.getText();
        Intent i = new Intent(ScannerActivity.this, PickupActivity.class);
        i.putExtra("PrsId",PrsId);
        i.putExtra("result", myResult);
        i.putExtra("validShipments",validShipments);
        i.putExtra("invalidShipments", invalidShipments);
        startActivity(i);

    }


}
