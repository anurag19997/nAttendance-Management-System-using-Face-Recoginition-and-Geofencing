package com.example.dtdcdeliveryapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class InventoryMoveActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_move);
    }
}
