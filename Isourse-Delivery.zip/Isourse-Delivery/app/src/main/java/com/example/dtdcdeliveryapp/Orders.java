package com.example.dtdcdeliveryapp;

import java.util.HashMap;

public class Orders {
    String client;
    String order_no;
    String sku;
    String skuDesc;
    String binCode;
    String pendingQuantity;
//    HashMap<String, Boolean> hashMap;




    public Orders() {
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public String getSkuDesc() {
        return skuDesc;
    }

    public void setSkuDesc(String skuDesc) {
        this.skuDesc = skuDesc;
    }

    public String getBinCode() {
        return binCode;
    }

    public void setBinCode(String binCode) {
        this.binCode = binCode;
    }

    public String getPendingQuantity() {
        return pendingQuantity;
    }

    public void setPendingQuantity(String pendingQuantity) {
        this.pendingQuantity = pendingQuantity;
    }

//    public HashMap<String, Boolean> getHashMap() {
//        return hashMap;
//    }
//
//    public void setHashMap(HashMap<String, Boolean> hashMap) {
//        this.hashMap = hashMap;
//    }

    public Orders(String client, String order_no, String sku, String skuDesc, String binCode, String pendingQuantity) {
        this.client = client;
        this.order_no = order_no;
        this.sku = sku;
        this.skuDesc = skuDesc;
        this.binCode = binCode;
        this.pendingQuantity = pendingQuantity;
//        this.hashMap = hashMap;
    }
}
