package com.example.dtdcdeliveryapp;

import android.content.Intent;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class FirstMileActivity extends AppCompatActivity {
    Toolbar main_app_bar;
    Button btn_vendor_pickup;
    TextView tv_distance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_mile);
        tv_distance = findViewById(R.id.tv_distance);
        btn_vendor_pickup = findViewById(R.id.btn_vendor_pickup);
        btn_vendor_pickup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                int perm = ContextCompat.checkSelfPermission(FirstMileActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
//                    if(perm == PackageManager.PERMISSION_GRANTED) {
                    Intent i = new Intent(FirstMileActivity.this, VendorPickupActivity.class);
                    startActivity(i);
//                }else{
//                    ActivityCompat.requestPermissions(FirstMileActivity.this,
//                            new String[] {
//                                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
//                                    Manifest.permission.READ_EXTERNAL_STORAGE
//                            },1000000);
//                    btn_vendor_pickup.callOnClick();
//                }
            }
        });
        SharedPreferences sharedPreferences = getSharedPreferences("SharedPreferences",MODE_PRIVATE);
        Float distance = sharedPreferences.getFloat("distance",0);
        tv_distance.setText(String.valueOf(distance));

//        PickupInfo pickupInfo =  new PickupInfo(0,"Tushar", 1, "5866093649", "01/05/2019",
//                12,"Surya", "Dwarka", "12345", 43436, "110059",
//                "Delhi", 123, "2134", "Audi");
//        PickupInfo pickupInfo2 =  new PickupInfo(1,"Pradeep", 1, "5866093649", "01/05/2019",
//                12,"Anurag", "Dwarka", "12345", 43436, "110059",
//                "Delhi", 123, "2134", "BMW");

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.first_mile_menu,menu);
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent i =new Intent(FirstMileActivity.this, Main3Activity.class);
        startActivity(i);
    }
}
