package com.example.dtdcdeliveryapp;

import org.json.JSONObject;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface UserClient {
    @POST("LoginResponseJson")
    Call<ResponseBody> createAccount(@Body User user);
}
