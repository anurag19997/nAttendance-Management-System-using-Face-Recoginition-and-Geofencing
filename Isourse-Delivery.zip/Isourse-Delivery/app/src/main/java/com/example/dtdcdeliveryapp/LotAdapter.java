package com.example.dtdcdeliveryapp;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class LotAdapter extends RecyclerView.Adapter<LotAdapter.LotViewHolder> {
    ArrayList<Lot> lots;

    public LotAdapter(ArrayList<Lot> lots) {
        this.lots = lots;
    }

    @NonNull
    @Override
    public LotViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater li = (LayoutInflater) viewGroup.getContext()
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View itemView = li.inflate(R.layout.list_item_lot, viewGroup, false);

        return new LotViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull LotViewHolder lotViewHolder, int i) {
        Lot lot = lots.get(i);
        lotViewHolder.textView.setText(String.valueOf(lot.left));
        lotViewHolder.editText.setText(String.valueOf(lot.right));
    }

    @Override
    public int getItemCount() {
        return lots.size();
    }

    public class LotViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        EditText editText;
        public LotViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.tv_left);
            editText = itemView.findViewById(R.id.et_right);
        }

    }
}
