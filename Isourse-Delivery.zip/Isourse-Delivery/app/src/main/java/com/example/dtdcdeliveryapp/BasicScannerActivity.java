package com.example.dtdcdeliveryapp;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.google.zxing.Result;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class BasicScannerActivity extends AppCompatActivity implements ZXingScannerView.ResultHandler {
    public static final String TAG = "BasicScannerActivity";
    private ZXingScannerView scannerView;
    String bincode;
    Boolean bincodePressed, usnPressed, skuPressed, is_sku_checked, is_fixed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_basic_scanner);
        Intent i  = getIntent();
        bincode = i.getStringExtra("bincode");
        is_fixed = i.getBooleanExtra("is_fixed",false);
        is_sku_checked = i.getBooleanExtra("is_sku_checked",false);
        bincodePressed = i.getBooleanExtra("bincodePressed", false);
        usnPressed = i.getBooleanExtra("usnPressed", false);
        skuPressed = i.getBooleanExtra("skuPressed", false);
        scannerView = new ZXingScannerView(this);
        setContentView(scannerView);
        scannerView.setResultHandler(this);
        scannerView.startCamera();
    }
    @Override
    public void handleResult(Result result) {
        final String myResult = result.getText();
        Intent i = new Intent(BasicScannerActivity.this, PutawayActivity.class);
        i.putExtra("is_fixed", is_fixed);
        i.putExtra("is_sku_checked", is_sku_checked);
        i.putExtra("result", myResult);
        i.putExtra("bincodePressed", bincodePressed);
        i.putExtra("usnPressed", usnPressed);
        i.putExtra("skuPressed", skuPressed);
        i.putExtra("bincode",bincode);
        startActivity(i);

    }
}
