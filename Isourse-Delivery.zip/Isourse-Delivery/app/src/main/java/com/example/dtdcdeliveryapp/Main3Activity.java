package com.example.dtdcdeliveryapp;

import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

import com.example.dtdcdeliveryapp.Adapters.TabAdapter;

import java.util.ArrayList;

public class Main3Activity extends AppCompatActivity {
    RecyclerView rv_main;
    ArrayList<Tab> tabs;
    TabAdapter tabAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        rv_main = findViewById(R.id.rv_main);
        tabs = new ArrayList<>();
        tabAdapter = new TabAdapter(tabs);
        tabGenerator(5);
        rv_main.setLayoutManager(new GridLayoutManager(
                this,
                1,
                LinearLayoutManager.VERTICAL,
                false
        ));
        rv_main.setAdapter(tabAdapter);
        rv_main.addOnItemTouchListener(new RecyclerTouchListener(Main3Activity.this, rv_main, new RecyclerTouchListener.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                switch (position){
                    case 0 :
                        Intent i0 = new Intent(Main3Activity.this, FirstMileActivity.class);
                        startActivity(i0);
                        break;
                    case 1 :
                        Intent i1 = new Intent(Main3Activity.this, InboundActivity.class);
                        startActivity(i1);
                        break;
                    case 2 :
                        Intent i2 = new Intent(Main3Activity.this, InventoryActivity.class);
                        startActivity(i2);
                        break;
                    case 3 :
                        Intent i3 = new Intent(Main3Activity.this, OutboundActivity.class);
                        startActivity(i3);
                        break;
                    case 4 :
                        Intent i4 = new Intent(Main3Activity.this, LoginActivity.class);
                        startActivity(i4);
                        break;
                }
            }
            @Override
            public void onLongClick(View view, int position) {

            }
        }));
    }
    public void tabGenerator(int n){
        Tab tab1 = new Tab("First Mile", R.drawable.first_mile_image, 1);
            tabs.add(tab1);
        Tab tab2 = new Tab("Inbound", R.drawable.inbound, 2);
        tabs.add(tab2);
        Tab tab3 = new Tab("Inventory", R.drawable.inventory, 3);
        tabs.add(tab3);
        Tab tab4 = new Tab("Outbound", R.drawable.outbound_image,4);
        tabs.add(tab4);
        Tab tab5 = new Tab("Last Mile", R.drawable.last_mile_image, 5);
        tabs.add(tab5);
            tabAdapter.notifyDataSetChanged();

    }
}
