package com.example.dtdcdeliveryapp.Adapters;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.dtdcdeliveryapp.AssignedPickup;
import com.example.dtdcdeliveryapp.R;

import java.util.ArrayList;

public class AssignedPickupAdapter extends RecyclerView.Adapter<AssignedPickupAdapter.AssignedPickupViewHolder> {
    ArrayList<AssignedPickup> assignedPickups;
    public  AssignedPickupAdapter(ArrayList<AssignedPickup> assignedPickups) {
        this.assignedPickups = assignedPickups;
    }

    @NonNull
    @Override
    public AssignedPickupAdapter.AssignedPickupViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater li = (LayoutInflater) viewGroup.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View itemView = li.inflate(R.layout.list_assigned_pickups, viewGroup, false);
        return  new AssignedPickupViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull AssignedPickupViewHolder assignedPickupViewHolder, int i) {
        AssignedPickup assignedPickup = assignedPickups.get(i);
        assignedPickupViewHolder.tv_prs_date.setText(assignedPickup.getSubTitle());
        assignedPickupViewHolder.tv_merchant_name.setText(assignedPickup.getTitle());


    }


    @Override
    public int getItemCount() {
        return assignedPickups.size();
    }

    class AssignedPickupViewHolder extends RecyclerView.ViewHolder  {
        TextView tv_merchant_name, tv_prs_date;
        Button button;
        public AssignedPickupViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_merchant_name = itemView.findViewById(R.id.tv_merchant_name);
            tv_prs_date = itemView.findViewById(R.id.tv_prs_date);
        }

    }
}
