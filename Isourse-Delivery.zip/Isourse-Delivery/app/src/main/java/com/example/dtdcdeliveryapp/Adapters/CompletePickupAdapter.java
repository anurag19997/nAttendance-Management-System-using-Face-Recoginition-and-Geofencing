package com.example.dtdcdeliveryapp.Adapters;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.dtdcdeliveryapp.CompletePickup;
import com.example.dtdcdeliveryapp.R;

import java.util.ArrayList;


public class CompletePickupAdapter extends RecyclerView.Adapter<CompletePickupAdapter.CompletePickupViewHolder> {
    ArrayList<CompletePickup> completePickups;

    public CompletePickupAdapter(ArrayList<CompletePickup> completePickups) {
        this.completePickups = completePickups;
    }

    @NonNull
    @Override
    public CompletePickupAdapter.CompletePickupViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        LayoutInflater li = (LayoutInflater) viewGroup.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View itemView = li.inflate(R.layout.list_complete_pickups, viewGroup, false);
        return  new CompletePickupViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull CompletePickupViewHolder completePickupViewHolder, int i) {
       CompletePickup completePickup = completePickups.get(i);
       completePickupViewHolder.tv_title.setText(completePickup.getTitle());
       completePickupViewHolder.tv_subTitle.setText(completePickup.getSubTitle());
       completePickupViewHolder.tv_pickup_status.setText(completePickup.getPickupStatus());
    }


    @Override
    public int getItemCount() {
        return completePickups.size();
    }

    class CompletePickupViewHolder extends RecyclerView.ViewHolder{
        TextView tv_title, tv_subTitle, tv_pickup_status;
        public CompletePickupViewHolder(@NonNull View itemView) {
            super(itemView);
            tv_title = itemView.findViewById(R.id.tv_title);
            tv_subTitle = itemView.findViewById(R.id.tv_sub_title);
            tv_pickup_status = itemView.findViewById(R.id.tv_pickup_status);
        }
    }
}

