package com.example.dtdcdeliveryapp;

import android.widget.TextView;

public class Lot {
    String left;
    String right;

    public Lot(String left, String right) {
        this.left = left;
        this.right = right;
    }

    public String getLeft() {
        return left;
    }

    public void setLeft(String left) {
        this.left = left;
    }

    public String getRight() {
        return right;
    }

    public void setRight(String right) {
        this.right = right;
    }
}
