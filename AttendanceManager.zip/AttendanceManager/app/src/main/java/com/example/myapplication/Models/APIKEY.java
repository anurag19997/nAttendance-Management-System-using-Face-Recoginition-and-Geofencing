package com.example.myapplication.Models;

public class APIKEY {
    int apikey;

    public APIKEY(int key) {
        this.apikey= key;
    }

    public int getKey() {
        return apikey;
    }

    public void setKey(int key) {
        this.apikey = key;
    }
}
