package com.example.myapplication.Activities;

public class NextActivity {
    public String calling = "Calling";
    public String meetings = "Meeting";

}
